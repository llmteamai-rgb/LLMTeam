"""Tests for persistence module."""

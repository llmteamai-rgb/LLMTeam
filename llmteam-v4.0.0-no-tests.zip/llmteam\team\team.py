"""
LLMTeam - Main team container.

Orchestrates AI agents using SegmentRunner internally.
"""

from typing import Any, Callable, Dict, List, Optional, Union
import uuid

from llmteam.agents.factory import AgentFactory
from llmteam.agents.config import AgentConfig
from llmteam.agents.base import BaseAgent
from llmteam.agents.presets import create_orchestrator_config
from llmteam.team.result import RunResult, RunStatus, ContextMode
from llmteam.team.snapshot import TeamSnapshot
from llmteam.team.converters import build_segment, result_from_segment_result


class LLMTeam:
    """
    Team of AI agents.

    Supports only three agent types: LLM, RAG, KAG.
    All external logic should be executed outside LLMTeam.

    Example:
        team = LLMTeam(
            team_id="content",
            agents=[
                {"type": "rag", "role": "retriever", "collection": "docs"},
                {"type": "llm", "role": "writer", "prompt": "Write about: {query}"}
            ]
        )
        result = await team.run({"query": "AI trends"})
    """

    def __init__(
        self,
        team_id: str,
        agents: Optional[List[Dict]] = None,
        flow: Union[str, Dict] = "sequential",
        model: str = "gpt-4o-mini",
        context_mode: ContextMode = ContextMode.SHARED,
        orchestration: bool = False,
        timeout: Optional[int] = None,
        **kwargs,
    ):
        """
        Initialize team.

        Args:
            team_id: Unique team identifier
            agents: List of agent configurations
            flow: Execution flow ("sequential", "a -> b -> c", or DAG dict)
            model: Default model for LLM agents
            context_mode: Context sharing mode (SHARED/NOT_SHARED)
            orchestration: Add orchestrator agent for adaptive flow
            timeout: Execution timeout in seconds
        """
        self.team_id = team_id
        self._flow = flow
        self._model = model
        self._context_mode = context_mode
        self._timeout = timeout
        self._has_orchestrator = False

        # Internal state
        self._agents: Dict[str, BaseAgent] = {}
        self._runner = None  # Lazy init
        self._runtime = None
        self._current_run_id: Optional[str] = None
        self._event_callbacks: Dict[str, List[Callable]] = {}
        self._mailbox: Dict[str, Any] = {}

        # Create agents from config
        if agents:
            for config in agents:
                self.add_agent(config)

        # Add orchestrator if needed
        if orchestration or flow == "adaptive":
            self._add_orchestrator()

    # Agent Management

    def add_agent(self, config: Union[Dict, AgentConfig]) -> BaseAgent:
        """
        Create and add agent from configuration.

        Args:
            config: Agent configuration dict or AgentConfig

        Returns:
            Created agent

        Raises:
            ValueError: If agent with same ID already exists
            ValueError: If agent type is not supported
        """
        agent = AgentFactory.create(team=self, config=config)

        if agent.agent_id in self._agents:
            raise ValueError(f"Agent '{agent.agent_id}' already exists in team")

        self._agents[agent.agent_id] = agent
        return agent

    def add_llm_agent(
        self,
        role: str,
        prompt: str,
        model: Optional[str] = None,
        **kwargs,
    ) -> BaseAgent:
        """Shortcut to add LLM agent."""
        config = {
            "type": "llm",
            "role": role,
            "prompt": prompt,
            "model": model or self._model,
            **kwargs,
        }
        return self.add_agent(config)

    def add_rag_agent(
        self,
        role: str = "rag",
        collection: str = "default",
        **kwargs,
    ) -> BaseAgent:
        """Shortcut to add RAG agent."""
        config = {
            "type": "rag",
            "role": role,
            "collection": collection,
            **kwargs,
        }
        return self.add_agent(config)

    def add_kag_agent(
        self,
        role: str = "kag",
        **kwargs,
    ) -> BaseAgent:
        """Shortcut to add KAG agent."""
        config = {
            "type": "kag",
            "role": role,
            **kwargs,
        }
        return self.add_agent(config)

    def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        """Get agent by ID."""
        return self._agents.get(agent_id)

    def list_agents(self) -> List[BaseAgent]:
        """List all agents."""
        return list(self._agents.values())

    def _add_orchestrator(self) -> None:
        """Add orchestrator agent for adaptive flow."""
        agent_roles = [
            a.role for a in self._agents.values() if not a.role.startswith("_")
        ]
        config = create_orchestrator_config(agent_roles, model=self._model)
        self.add_agent(config)
        self._has_orchestrator = True

    # Execution

    async def run(
        self,
        input_data: Dict[str, Any],
        run_id: Optional[str] = None,
    ) -> RunResult:
        """
        Execute team.

        Internally converts agents to SegmentDefinition and delegates to SegmentRunner.

        Args:
            input_data: Input data for execution
            run_id: Optional run identifier

        Returns:
            RunResult with output and metadata
        """
        from datetime import datetime

        run_id = run_id or str(uuid.uuid4())
        self._current_run_id = run_id
        started_at = datetime.utcnow()

        if not self._agents:
            return RunResult(
                success=False,
                status=RunStatus.FAILED,
                error="No agents in team",
            )

        try:
            # Build segment from agents
            segment = build_segment(
                team_id=self.team_id,
                agents=self._agents,
                flow=self._flow,
            )

            # Get or create runner
            runner = self._get_runner()

            # Build runtime context
            runtime = self._build_runtime(run_id)

            # Run segment
            from llmteam.canvas.runner import RunConfig

            config = RunConfig()
            if self._timeout:
                config.timeout_seconds = self._timeout

            segment_result = await runner.run(
                segment=segment,
                input_data=input_data,
                runtime=runtime,
                config=config,
            )

            # Convert result
            result = result_from_segment_result(segment_result, self._agents)
            result.started_at = started_at
            result.completed_at = datetime.utcnow()

            return result

        except Exception as e:
            return RunResult(
                success=False,
                status=RunStatus.FAILED,
                error=str(e),
                started_at=started_at,
                completed_at=datetime.utcnow(),
            )

        finally:
            self._current_run_id = None

    # Pause/Resume

    async def pause(self) -> TeamSnapshot:
        """
        Pause execution and return snapshot.

        Returns:
            TeamSnapshot for resume
        """
        if not self._current_run_id:
            raise RuntimeError("No active run to pause")

        runner = self._get_runner()
        segment_snapshot = await runner.pause(self._current_run_id)

        return TeamSnapshot.from_segment_snapshot(segment_snapshot, self.team_id)

    async def resume(self, snapshot: TeamSnapshot) -> RunResult:
        """
        Resume execution from snapshot.

        Args:
            snapshot: TeamSnapshot from pause()

        Returns:
            RunResult
        """
        runner = self._get_runner()

        # Build segment
        segment = build_segment(
            team_id=self.team_id,
            agents=self._agents,
            flow=self._flow,
        )

        # Convert to segment snapshot
        segment_snapshot = snapshot.to_segment_snapshot()

        # Build runtime
        runtime = self._build_runtime(snapshot.run_id)

        # Resume
        segment_result = await runner.resume(
            snapshot=segment_snapshot,
            segment=segment,
            runtime=runtime,
        )

        return result_from_segment_result(segment_result, self._agents)

    async def cancel(self) -> bool:
        """
        Cancel current execution.

        Returns:
            True if cancelled successfully
        """
        if not self._current_run_id:
            return False

        runner = self._get_runner()
        return await runner.cancel(self._current_run_id)

    # Events

    def on(self, event: str, callback: Callable) -> None:
        """
        Register event callback.

        Args:
            event: Event name (e.g., "agent_complete", "step_start")
            callback: Callback function
        """
        if event not in self._event_callbacks:
            self._event_callbacks[event] = []
        self._event_callbacks[event].append(callback)

    def off(self, event: str, callback: Callable) -> None:
        """Remove event callback."""
        if event in self._event_callbacks:
            self._event_callbacks[event] = [
                cb for cb in self._event_callbacks[event] if cb != callback
            ]

    # Escalation

    async def escalate(
        self,
        source_agent: str,
        reason: str,
        context: Optional[Dict] = None,
    ) -> Any:
        """
        Handle escalation from agent.

        Args:
            source_agent: Agent ID that escalated
            reason: Escalation reason
            context: Additional context

        Returns:
            Escalation decision
        """
        # TODO: Integrate with escalation subsystem
        return {
            "action": "continue",
            "source": source_agent,
            "reason": reason,
        }

    # Groups

    def create_group(
        self,
        group_id: str,
        teams: List["LLMTeam"],
    ) -> "LLMGroup":
        """
        Create a group with this team as leader.

        Args:
            group_id: Group identifier
            teams: Other teams in the group

        Returns:
            LLMGroup instance
        """
        from llmteam.team.group import LLMGroup

        return LLMGroup(
            group_id=group_id,
            leader=self,
            teams=teams,
            model=self._model,
        )

    # Serialization

    def to_config(self) -> Dict[str, Any]:
        """Export team configuration."""
        return {
            "team_id": self.team_id,
            "agents": [agent.to_dict() for agent in self._agents.values()],
            "flow": self._flow,
            "model": self._model,
            "context_mode": self._context_mode.value,
        }

    @classmethod
    def from_config(cls, config: Dict[str, Any]) -> "LLMTeam":
        """Create team from configuration."""
        return cls(
            team_id=config["team_id"],
            agents=config.get("agents", []),
            flow=config.get("flow", "sequential"),
            model=config.get("model", "gpt-4o-mini"),
            context_mode=ContextMode(config.get("context_mode", "shared")),
        )

    @classmethod
    def from_segment(cls, segment, team_id: Optional[str] = None) -> "LLMTeam":
        """
        Create team from SegmentDefinition.

        Args:
            segment: SegmentDefinition
            team_id: Optional team ID (default: segment_id)

        Returns:
            LLMTeam
        """
        team = cls(
            team_id=team_id or segment.segment_id,
            flow={"edges": [e.to_dict() for e in segment.edges]},
        )

        # Convert steps to agents
        for step in segment.steps:
            if step.type in ("llm", "rag", "kag"):
                config = {"type": step.type, "role": step.step_id, **step.config}
                team.add_agent(config)

        return team

    # Internal

    def _get_runner(self):
        """Get or create SegmentRunner."""
        if self._runner is None:
            from llmteam.canvas.runner import SegmentRunner

            self._runner = SegmentRunner()
        return self._runner

    def _build_runtime(self, run_id: str):
        """Build RuntimeContext for execution."""
        from llmteam.runtime import RuntimeContextFactory

        if self._runtime:
            return self._runtime.child_context(run_id)

        # Create minimal runtime
        factory = RuntimeContextFactory()
        return factory.create_runtime(
            tenant_id="default",
            instance_id=run_id,
        )

    def set_runtime(self, runtime) -> None:
        """Set runtime context for execution."""
        self._runtime = runtime

    # Magic methods

    def __repr__(self) -> str:
        return f"<LLMTeam id='{self.team_id}' agents={len(self._agents)}>"

    def __len__(self) -> int:
        return len(self._agents)

    def __contains__(self, agent_id: str) -> bool:
        return agent_id in self._agents

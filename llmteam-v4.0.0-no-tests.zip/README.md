# llmteam-ai

Enterprise AI Workflow Runtime for building multi-agent LLM pipelines with security, orchestration, and workflow capabilities.

[![PyPI version](https://badge.fury.io/py/llmteam-ai.svg)](https://pypi.org/project/llmteam-ai/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

## Current Version: v3.0.0 — Clean Break Architecture

### New Features in v3.0.0

- **Agent Abstraction** — Base `Agent` class with `process()` method, `AgentState`/`AgentResult` for clean I/O
- **LLMTeam Container** — Primary team class replacing PipelineOrchestrator, with `team.run()` API
- **Team Orchestrator** — Pluggable strategies (Sequential, RoundRobin, LLMRouting) for agent execution
- **Group Orchestrator** — Pure coordinator for multi-team workflows with escalation handling
- **Escalation Subsystem** — Structured escalation with levels, actions, and pluggable handlers
- **Generic Registries** — Type-safe `BaseRegistry[T]`, `AgentRegistry`, `TeamRegistry`
- **Compatibility Layer** — `LegacyPipelineOrchestrator` for v2.x migration

## Installation

```bash
pip install llmteam-ai

# With PostgreSQL support
pip install llmteam-ai[postgres]

# With API server (FastAPI)
pip install llmteam-ai[api]

# With all optional dependencies
pip install llmteam-ai[all]
```

## Quick Start

### Create an Agent Team (v3.0.0)

```python
from llmteam import LLMTeam, Agent, AgentState, AgentResult

# Define custom agent
class TriageAgent(Agent):
    async def process(self, state: AgentState) -> AgentResult:
        query = state.data.get("query", "")
        category = "billing" if "bill" in query.lower() else "general"
        return AgentResult(output={"category": category, "query": query})

class ResolverAgent(Agent):
    async def process(self, state: AgentState) -> AgentResult:
        category = state.data.get("category", "general")
        return AgentResult(output={"resolution": f"Handled {category} request"})

# Create team and register agents
team = LLMTeam(team_id="support_team", name="Customer Support")
team.register_agent(TriageAgent("triage"))
team.register_agent(ResolverAgent("resolver"))

# Run team
result = await team.run({"query": "I have a billing question"})
print(result.output)  # {"resolution": "Handled billing request", ...}
print(result.agents_invoked)  # ["triage", "resolver"]
```

### Define and Run a Canvas Segment

```python
from llmteam.canvas import SegmentDefinition, StepDefinition, EdgeDefinition, SegmentRunner
from llmteam.runtime import RuntimeContextFactory

# Create runtime context
factory = RuntimeContextFactory()
factory.register_team(team)  # Register our team
runtime = factory.create_runtime(tenant_id="acme", instance_id="workflow-1")

# Define segment that invokes the team
segment = SegmentDefinition(
    segment_id="support_workflow",
    name="Support Workflow",
    steps=[
        StepDefinition(step_id="input", step_type="transform", config={"expression": "input"}),
        StepDefinition(step_id="support", step_type="team", config={"team_ref": "support_team"}),
    ],
    edges=[
        EdgeDefinition(source_step="input", source_port="output", target_step="support", target_port="input"),
    ],
)

# Run segment
runner = SegmentRunner()
result = await runner.run(segment=segment, input_data={"query": "Billing issue"}, runtime=runtime)
print(result.status)  # SegmentStatus.COMPLETED
```

### CLI Usage

```bash
# Validate segment definition
llmteam validate segment.json

# Run segment
llmteam run segment.json --input-json '{"query": "Hello"}'

# List available step types
llmteam catalog

# Start API server
llmteam serve --port 8000
```

## Features

### v3.0.0 — Clean Break Architecture

#### Agent Abstraction

Define agents with a clean interface.

```python
from llmteam import Agent, AgentState, AgentResult, FunctionAgent

# Custom agent class
class AnalyzerAgent(Agent):
    async def process(self, state: AgentState) -> AgentResult:
        data = state.data.get("input", {})
        analysis = {"sentiment": "positive", "confidence": 0.95}
        return AgentResult(output=analysis)

# Or use FunctionAgent for simple cases
async def simple_handler(state: AgentState) -> AgentResult:
    return AgentResult(output={"processed": True})

agent = FunctionAgent("simple", simple_handler)
```

#### LLMTeam Container

Create and manage teams of agents.

```python
from llmteam import LLMTeam, TeamConfig
from llmteam.orchestration import TeamOrchestrator, SequentialStrategy

# Create team with configuration
team = LLMTeam(
    team_id="analysis_team",
    name="Data Analysis Team",
    config=TeamConfig(strict_validation=True, max_iterations=10),
)

# Register agents
team.register_agent(AnalyzerAgent("analyzer"))
team.register_agent(SummarizerAgent("summarizer"))

# Optional: Set custom orchestrator
team.orchestrator = TeamOrchestrator(strategy=SequentialStrategy())

# Run team
result = await team.run({"input": data}, run_id="run-123")
print(result.output)
print(result.agents_invoked)  # ["analyzer", "summarizer"]
```

#### Escalation Handling

Handle agent and team escalations.

```python
from llmteam.escalation import (
    EscalationLevel, Escalation, DefaultHandler, ThresholdHandler, ChainHandler
)

# Create escalation handler chain
handler = ChainHandler([
    ThresholdHandler(threshold=3, threshold_action=EscalationAction.HUMAN_REVIEW),
    DefaultHandler(),
])

# Handle escalation
escalation = Escalation(
    level=EscalationLevel.WARNING,
    source_team="billing_team",
    reason="Refund amount exceeds policy limit",
)
decision = handler.handle(escalation)
print(decision.action)  # EscalationAction.ACKNOWLEDGE or HUMAN_REVIEW
```

#### Group Orchestrator

Coordinate multiple teams.

```python
from llmteam.orchestration import GroupOrchestrator, GroupMetrics

# Create group
group = GroupOrchestrator(group_id="support_group")
group.register_team(billing_team)
group.register_team(technical_team)

# Handle team escalations
await group.handle_team_escalation({
    "team_id": "billing_team",
    "reason": "Complex case",
    "level": "warning",
})

# Get metrics
metrics: GroupMetrics = group.collect_metrics()
print(metrics.team_health)  # {"billing_team": 0.95, "technical_team": 1.0}
```

### v2.0.0 — Canvas Integration

#### Runtime Context

Inject runtime resources (stores, clients, secrets, LLMs, teams) into step execution.

```python
from llmteam.runtime import RuntimeContextFactory

factory = RuntimeContextFactory()
factory.register_store("redis", redis_store)
factory.register_llm("gpt4", openai_provider)
factory.register_team(support_team)  # v3.0.0: Register teams

runtime = factory.create_runtime(tenant_id="acme", instance_id="workflow_123")
step_ctx = runtime.child_context("process_data")

# Access resources
store = step_ctx.get_store("redis")
llm = step_ctx.get_llm("gpt4")
team = step_ctx.get_team("support_team")  # v3.0.0
```

#### Built-in Step Types

| Type | Category | Description |
|------|----------|-------------|
| `llm_agent` | AI | LLM-powered agent step |
| `team` | AI | **v3.0.0** Execute agent teams |
| `transform` | Data | Data transformation |
| `human_task` | Human | Human approval/input |
| `condition` | Control | Conditional branching |
| `switch` | Control | Multi-way branching |
| `parallel_split` | Control | Fan-out to parallel branches |
| `parallel_join` | Control | Merge parallel results |
| `subworkflow` | Control | Nested workflow execution |
| `http_action` | Integration | HTTP requests |
| `rag` | AI | Retrieval-augmented generation |

### Previous Versions

#### v1.9.0 — Workflow Runtime
- External Actions (API/webhook calls with retry)
- Human-in-the-loop interaction (approval, chat, escalation)
- Snapshot-based pause/resume for long-running workflows

#### v1.8.0 — Orchestration Intelligence
- Hierarchical context propagation
- Pipeline orchestration with smart routing
- Process mining with XES export
- License-based feature management

#### v1.7.0 — Security Foundation
- Multi-tenant isolation with configurable limits
- Compliance audit trail with SHA-256 chain integrity
- Secure agent context with sealed data
- Rate limiting with circuit breaker

## Architecture

```
llmteam/
├── agent.py          # Agent abstraction (v3.0.0)
├── team.py           # LLMTeam container (v3.0.0)
├── registry/         # Generic registries (v3.0.0)
│   ├── base.py       # BaseRegistry[T]
│   ├── agent_registry.py
│   └── team_registry.py
├── orchestration/    # Orchestration (v3.0.0)
│   ├── team_orchestrator.py   # TeamOrchestrator with strategies
│   └── group_orchestrator.py  # GroupOrchestrator coordinator
├── escalation/       # Escalation subsystem (v3.0.0)
│   ├── models.py     # EscalationLevel, Escalation, etc.
│   └── handlers.py   # Default, Threshold, Chain handlers
├── compat/           # v2.x compatibility (v3.0.0)
├── runtime/          # Runtime context injection (v2.0.0)
├── events/           # Worktrail events (v2.0.0)
├── canvas/           # Canvas segment execution (v2.0.0)
│   ├── models.py     # SegmentDefinition, StepDefinition
│   ├── catalog.py    # StepCatalog with 12 built-in types
│   ├── runner.py     # SegmentRunner execution engine
│   └── handlers/     # Step handlers (LLM, Team, Transform, etc.)
├── roles/            # Legacy orchestration (v1.8.0)
├── tenancy/          # Multi-tenant isolation (v1.7.0)
├── audit/            # Compliance audit trail (v1.7.0)
├── cli/              # Command-line interface
├── api/              # REST API with FastAPI
└── observability/    # Structured logging
```

### Core Concept: Teams as Canvas Steps

```
Canvas (SegmentRunner)         — Workflow routing (edges, conditions)
       │
       ▼
GroupOrchestrator              — Multi-team coordination, escalations
       │
       ▼
LLMTeam                        — Agent container with TeamOrchestrator
       │
       ▼
Agents                         — Individual AI agents (LLM calls, tools)
```

## Key Principles

### Security

1. **Horizontal Isolation**: Agents NEVER see each other's contexts
2. **Vertical Visibility**: Orchestrators see only their child agents
3. **Sealed Data**: Only the owning agent can access sealed fields
4. **Tenant Isolation**: Complete data separation between tenants
5. **Instance Namespacing**: Workflow instances isolated within tenant

### Canvas Integration

1. **JSON Contract**: Segments defined as portable JSON
2. **Step Catalog**: Extensible registry of step types
3. **Event-Driven**: UI updates via Worktrail events
4. **Resource Injection**: Runtime context provides stores, clients, secrets

## Links

- [PyPI Package](https://pypi.org/project/llmteam-ai/)
- [GitHub Repository](https://github.com/llmteamai-rgb/LLMTeam)
- [Changelog](https://github.com/llmteamai-rgb/LLMTeam/blob/main/llmteam/CHANGELOG.md)

## License

Apache 2.0 License

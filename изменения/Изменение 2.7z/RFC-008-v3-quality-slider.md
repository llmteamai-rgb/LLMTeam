# RFC-008 v3: Quality Slider — Один параметр для всего

**Дата:** 2026-01-21  
**Статус:** DRAFT v3  
**Автор:** @Architect + @PM  
**Приоритет:** P1

---

## Ключевая идея

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   QUALITY SLIDER: 0% ──────────────────────────────────────────── 100%     │
│                                                                             │
│                    │                    │                    │              │
│                    ▼                    ▼                    ▼              │
│               Максимум             Баланс              Максимум            │
│               экономии                                 качества            │
│                                                                             │
│   Модели:     gpt-4o-mini          gpt-4o            gpt-4-turbo          │
│   Стоимость:  ~$0.02/run          ~$0.15/run         ~$0.80/run           │
│   Качество:   Базовое             Хорошее            Отличное             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

Один параметр. Всё остальное — автоматически.
```

---

## 1. Почему это лучше

| Подход | Параметры | Когнитивная нагрузка |
|--------|-----------|---------------------|
| v1: Токены | max_tokens, throttle_model, ... | Высокая |
| v2: Tiers | economy/standard/premium | Средняя |
| **v3: Slider** | **quality=70** | **Минимальная** |

**Аналогия:** Как ползунок "качество" при экспорте JPEG — один параметр, понятный всем.

---

## 2. API

### 2.1 Базовое использование

```python
from llmteam import LLMTeam

# Один параметр: quality от 0 до 100
team = LLMTeam(quality=70)  # 70% — хороший баланс

result = await team.run({"topic": "AI"})
print(f"Cost: ${result.cost:.4f}")
```

### 2.2 Defaults

```python
# Без параметров = quality=50 (баланс)
team = LLMTeam()

# Эквивалентно
team = LLMTeam(quality=50)
```

### 2.3 Override per run

```python
team = LLMTeam(quality=50)  # Default для команды

# Для важного запроса — выше качество
result = await team.run(important_data, quality=90)

# Для теста — ниже качество  
result = await team.run(test_data, quality=20)
```

---

## 3. Как Slider влияет на Pipeline

### 3.1 Выбор моделей

```python
def get_model_for_task(task_complexity: str, quality: int) -> str:
    """
    Выбор модели на основе сложности задачи и quality slider.
    
    Матрица выбора:
    
                    quality: 0-30    30-70      70-100
    ─────────────────────────────────────────────────────
    simple task:    mini        mini       4o
    medium task:    mini        4o         4o-turbo  
    complex task:   4o          4o-turbo   4o-turbo/opus
    """
    
    MODEL_MATRIX = {
        "simple": {
            (0, 30): "gpt-4o-mini",
            (30, 70): "gpt-4o-mini", 
            (70, 100): "gpt-4o",
        },
        "medium": {
            (0, 30): "gpt-4o-mini",
            (30, 70): "gpt-4o",
            (70, 100): "gpt-4-turbo",
        },
        "complex": {
            (0, 30): "gpt-4o",
            (30, 70): "gpt-4-turbo",
            (70, 100): "gpt-4-turbo",  # или claude-3-opus
        },
    }
    
    for (low, high), model in MODEL_MATRIX[task_complexity].items():
        if low <= quality <= high:
            return model
```

### 3.2 Влияние на структуру Pipeline

Quality slider влияет не только на модели, но и на **архитектуру pipeline**:

```
quality=20 (экономия):
┌──────────────┐
│   Один       │    Простой pipeline, 1-2 агента
│   агент      │    Дешёвые модели
│   "всё в     │    Меньше проверок
│   одном"     │
└──────────────┘


quality=50 (баланс):
┌──────────┐     ┌──────────┐     ┌──────────┐
│ Extract  │ ──► │ Process  │ ──► │ Format   │
│ (mini)   │     │ (4o)     │     │ (mini)   │
└──────────┘     └──────────┘     └──────────┘


quality=90 (максимум):
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│ Extract  │ ──► │ Analyze  │ ──► │ Write    │ ──► │ Review   │
│ (4o)     │     │ (turbo)  │     │ (turbo)  │     │ (turbo)  │
└──────────┘     └──────────┘     └──────────┘     └──────────┘
                                                        │
                                                        ▼
                                                   ┌──────────┐
                                                   │ Polish   │
                                                   │ (4o)     │
                                                   └──────────┘
```

### 3.3 Параметры генерации

```python
def get_generation_params(quality: int) -> dict:
    """Quality влияет на параметры генерации."""
    
    if quality < 30:
        return {
            "max_tokens": 500,      # Короткие ответы
            "temperature": 0.3,     # Более детерминированно
        }
    elif quality < 70:
        return {
            "max_tokens": 1000,
            "temperature": 0.5,
        }
    else:
        return {
            "max_tokens": 2000,     # Развёрнутые ответы
            "temperature": 0.7,     # Более креативно
        }
```

---

## 4. CONFIGURATOR с Quality Slider

### 4.1 Генерация Pipeline под Quality

```python
session = await team.configure(
    task="Generate marketing report from sales data"
)

# CONFIGURATOR спрашивает только одно:
print("Select quality level (0-100):")
print("  0-30:  Fast & cheap, basic output")
print("  30-70: Balanced, good for most tasks")  
print("  70-100: Best quality, thorough analysis")

session.set_quality(60)  # Пользователь выбирает

# CONFIGURATOR генерирует оптимальный pipeline для quality=60
pipeline = await session.generate_pipeline()
```

### 4.2 Что генерирует CONFIGURATOR

```python
# Для quality=30 (экономия):
pipeline_30 = {
    "agents": [
        {"role": "processor", "model": "gpt-4o-mini", "task": "Extract and format data"}
    ],
    "estimated_cost": 0.02,
}

# Для quality=60 (баланс):
pipeline_60 = {
    "agents": [
        {"role": "extractor", "model": "gpt-4o-mini", "task": "Extract key metrics"},
        {"role": "analyzer", "model": "gpt-4o", "task": "Analyze trends"},
        {"role": "writer", "model": "gpt-4o", "task": "Write report"},
    ],
    "estimated_cost": 0.18,
}

# Для quality=90 (максимум):
pipeline_90 = {
    "agents": [
        {"role": "extractor", "model": "gpt-4o", "task": "Deep data extraction"},
        {"role": "analyzer", "model": "gpt-4-turbo", "task": "Comprehensive analysis"},
        {"role": "strategist", "model": "gpt-4-turbo", "task": "Strategic insights"},
        {"role": "writer", "model": "gpt-4-turbo", "task": "Executive report"},
        {"role": "reviewer", "model": "gpt-4-turbo", "task": "Quality review"},
    ],
    "estimated_cost": 0.85,
}
```

### 4.3 Preview перед применением

```python
session.set_quality(60)
preview = await session.preview()

print(preview)
```

**Output:**
```
Pipeline Preview (quality=60):

Agents:
  1. extractor (gpt-4o-mini) — Extract key metrics
  2. analyzer (gpt-4o) — Analyze trends  
  3. writer (gpt-4o) — Write report

Flow: extractor → analyzer → writer

Estimated cost: $0.15-0.20 per run
Estimated quality: ⭐⭐⭐⭐ (Good)

[Apply] [Adjust quality] [Customize]
```

---

## 5. Интерактивный режим

### 5.1 Slider в UI/CLI

```
Configure team for: "Generate marketing report"

Quality: [████████░░░░░░░░░░░░] 40%

Estimated:
  • Cost: ~$0.08/run
  • Agents: 2
  • Models: gpt-4o-mini, gpt-4o

↑/↓ to adjust, Enter to confirm
```

### 5.2 Быстрая настройка через presets

```python
# Именованные presets = конкретные значения quality
team = LLMTeam(quality="draft")      # = quality=20
team = LLMTeam(quality="balanced")   # = quality=50  
team = LLMTeam(quality="production") # = quality=75
team = LLMTeam(quality="best")       # = quality=95

# Или числом напрямую
team = LLMTeam(quality=65)
```

---

## 6. Cost Estimation по Quality

### 6.1 Формула

```python
def estimate_cost(task_complexity: str, quality: int) -> tuple[float, float]:
    """
    Оценка стоимости по сложности задачи и quality.
    
    Returns:
        (min_cost, max_cost) — диапазон
    """
    
    # Базовая стоимость по сложности задачи
    BASE_COSTS = {
        "simple": 0.01,
        "medium": 0.05,
        "complex": 0.15,
    }
    
    base = BASE_COSTS[task_complexity]
    
    # Quality множитель: от 0.5x (quality=0) до 5x (quality=100)
    multiplier = 0.5 + (quality / 100) * 4.5
    
    estimated = base * multiplier
    
    # Диапазон ±30%
    return (estimated * 0.7, estimated * 1.3)
```

### 6.2 Показывать пользователю

```python
team = LLMTeam(quality=70)

estimate = await team.estimate_cost(input_data)
print(f"Estimated cost: ${estimate.min:.2f} - ${estimate.max:.2f}")
# "Estimated cost: $0.12 - $0.22"
```

---

## 7. Budget Limits (опционально)

Quality slider — основной параметр. Budget limit — страховка:

```python
# Только quality (рекомендуется)
team = LLMTeam(quality=70)

# Quality + страховочный лимит
team = LLMTeam(
    quality=70,
    max_cost_per_run=1.00,  # Страховка от случайных больших затрат
)

# Если pipeline не влезает в лимит — предупреждение
result = await team.run(huge_data)
# ⚠️ Warning: Estimated cost $1.20 exceeds limit $1.00
# Suggestion: Lower quality to 55 to fit budget
```

---

## 8. Адаптивный Quality

### 8.1 Auto-adjust по бюджету

```python
team = LLMTeam(
    quality="auto",           # Автоматический выбор
    daily_budget=10.00,       # $10/день
)

# Система сама регулирует quality:
# - Утром, когда бюджет полный: quality≈70
# - К вечеру, если много потрачено: quality≈40
# - Если бюджет почти исчерпан: quality≈20
```

### 8.2 Quality по важности задачи

```python
# Можно передать "важность" задачи
result = await team.run(
    data,
    importance="high",  # high/medium/low
)

# importance влияет на quality:
# high → quality + 20
# medium → quality (без изменений)
# low → quality - 20
```

---

## 9. Полный пример User Journey

```python
from llmteam import LLMTeam

# 1. Создание команды с quality
team = LLMTeam(quality=60)

# 2. Конфигурация через CONFIGURATOR
session = await team.configure(
    task="Analyze customer feedback and generate insights report"
)

# 3. Preview pipeline для текущего quality
preview = await session.preview()
print(f"Pipeline: {len(preview.agents)} agents")
print(f"Estimated cost: ${preview.estimated_cost:.2f}/run")

# Если дорого — снизить quality
if preview.estimated_cost > 0.30:
    session.set_quality(45)
    preview = await session.preview()  # Новый preview

# 4. Применить конфигурацию
await session.apply()

# 5. Запуск
result = await team.run({"feedback": customer_data})

print(f"Actual cost: ${result.cost:.4f}")
print(f"Quality used: {result.quality_used}")

# 6. Для важного клиента — повысить quality
vip_result = await team.run(
    {"feedback": vip_customer_data},
    quality=85,  # Override для этого запроса
)
```

---

## 10. Сравнение подходов

| Аспект | v2 (Tiers) | v3 (Slider) |
|--------|------------|-------------|
| Параметры | 3 варианта | 0-100 континуум |
| Гибкость | Низкая | Высокая |
| Понятность | "Что такое standard?" | "70 из 100" |
| Точная настройка | ❌ | ✅ |
| Когнитивная нагрузка | Средняя | Минимальная |

---

## 11. Реализация

### 11.1 QualityManager

```python
class QualityManager:
    """Управление quality slider."""
    
    def __init__(self, quality: int = 50):
        self._quality = self._normalize(quality)
    
    def _normalize(self, quality) -> int:
        """Нормализовать значение quality."""
        if isinstance(quality, str):
            presets = {
                "draft": 20,
                "economy": 30,
                "balanced": 50,
                "production": 75,
                "best": 95,
            }
            return presets.get(quality, 50)
        return max(0, min(100, int(quality)))
    
    def get_model(self, task_complexity: str) -> str:
        """Получить модель для задачи."""
        return get_model_for_task(task_complexity, self._quality)
    
    def get_pipeline_depth(self) -> str:
        """Рекомендуемая глубина pipeline."""
        if self._quality < 30:
            return "shallow"   # 1-2 агента
        elif self._quality < 70:
            return "medium"    # 2-4 агента
        else:
            return "deep"      # 3-6 агентов
    
    def get_generation_params(self) -> dict:
        """Параметры генерации."""
        return get_generation_params(self._quality)
    
    def estimate_cost_multiplier(self) -> float:
        """Множитель стоимости относительно базовой."""
        return 0.5 + (self._quality / 100) * 4.5
```

### 11.2 Интеграция в LLMTeam

```python
class LLMTeam:
    def __init__(self, quality: int | str = 50, **kwargs):
        self._quality_manager = QualityManager(quality)
        # ...
    
    @property
    def quality(self) -> int:
        return self._quality_manager._quality
    
    @quality.setter
    def quality(self, value: int | str):
        self._quality_manager = QualityManager(value)
    
    async def run(self, input_data: dict, quality: int = None, **kwargs):
        # Override quality для этого run
        effective_quality = quality if quality is not None else self.quality
        
        # Использовать для выбора моделей и параметров
        # ...
```

---

## 12. Definition of Done

- [ ] QualityManager с нормализацией 0-100
- [ ] Маппинг quality → модели для разных сложностей
- [ ] Маппинг quality → глубина pipeline
- [ ] Маппинг quality → параметры генерации
- [ ] LLMTeam(quality=N) работает
- [ ] Override quality в run()
- [ ] CONFIGURATOR генерирует pipeline по quality
- [ ] Preview с estimated cost
- [ ] Presets (draft/balanced/production/best)
- [ ] Документация

---

## 13. Summary

```
Было (v2):                      Стало (v3):
─────────────────               ─────────────────
quality="economy"               quality=25
quality="standard"      →       quality=50  
quality="premium"               quality=85

Три варианта                    Континуум 0-100
```

**Один параметр. Интуитивно понятный. Гибкий.**

---

**Рекомендация: ПРИНЯТЬ v3**

Проще для пользователя, гибче для системы.

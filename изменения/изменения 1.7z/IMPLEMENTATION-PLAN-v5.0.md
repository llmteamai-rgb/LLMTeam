# План внедрения RFC v5.0

**Дата:** 2026-01-21
**Версия:** v5.0.0
**Статус:** APPROVED

---

## Обзор изменений

| RFC | Название | Изменение в плане |
|-----|----------|-------------------|
| RFC-004 | GroupOrchestrator | Без изменений |
| RFC-005 | CONFIGURATOR Mode | Без изменений |
| RFC-006 | Canvas → Optional Engine | **`canvas/` → `engine/`** + **опциональный модуль** |
| RFC-007 | Agent Encapsulation | Без изменений |

### RFC-006 REVISED: Canvas как опциональный модуль

**Ключевое изменение:** Engine становится опциональным (`pip install llmteam-ai[engine]`)

| Режим | Установка | Возможности |
|-------|-----------|-------------|
| **Core** | `pip install llmteam-ai` | LLMTeam, простой flow, orchestration |
| **Full** | `pip install llmteam-ai[engine]` | + DAG workflows, parallel, human tasks |

---

## Phase 1: Breaking Changes (v5.0.0)

### 1.1 RFC-006: Canvas → Optional Engine (Week 1-2)

**Задачи:**

| # | Задача | Файлы |
|---|--------|-------|
| 1 | Переименовать директорию | `canvas/` → `engine/` |
| 2 | Переименовать runner.py | `runner.py` → `engine.py` |
| 3 | Переименовать классы | См. таблицу ниже |
| 4 | Обновить внутренние imports | Все файлы в `engine/` |
| 5 | Сделать Engine опциональным | `pyproject.toml` → `[engine]` extra |
| 6 | Lazy imports в `__init__.py` | ImportError при отсутствии Engine |
| 7 | Обновить LLMTeam | Работа без Engine (simple flow) |
| 8 | Добавить deprecation warnings | `__getattr__` для старых имён |
| 9 | Тесты Core-only | `tests/core/test_without_engine.py` |
| 10 | Обновить тесты Engine | `tests/canvas/` → `tests/engine/` |

**Таблица переименований:**

| Before | After |
|--------|-------|
| `canvas/` | `engine/` |
| `canvas/runner.py` | `engine/engine.py` |
| `SegmentRunner` | `ExecutionEngine` |
| `SegmentDefinition` | `WorkflowDefinition` |
| `SegmentResult` | `ExecutionResult` |
| `SegmentStatus` | `ExecutionStatus` |
| `SegmentSnapshot` | `ExecutionSnapshot` |
| `CanvasError` | `EngineError` |
| `segment_id` | `workflow_id` |

**Backward compatibility:**

```python
# llmteam/__init__.py
import warnings

_DEPRECATED_NAMES = {
    "SegmentRunner": "ExecutionEngine",
    "SegmentDefinition": "WorkflowDefinition",
    "SegmentResult": "ExecutionResult",
    "SegmentStatus": "ExecutionStatus",
    "SegmentSnapshot": "ExecutionSnapshot",
}

def __getattr__(name):
    if name in _DEPRECATED_NAMES:
        warnings.warn(
            f"{name} is deprecated, use {_DEPRECATED_NAMES[name]} instead",
            DeprecationWarning,
            stacklevel=2
        )
        from llmteam import engine
        return getattr(engine, _DEPRECATED_NAMES[name])
    raise AttributeError(f"module 'llmteam' has no attribute '{name}'")
```

---

### 1.2 RFC-007: Agent Encapsulation (Week 2-4)

**Задачи:**

| # | Задача | Файлы |
|---|--------|-------|
| 1 | Переименовать `process()` → `_process()` | `agents/base.py` |
| 2 | Добавить RuntimeError в `process()` | `agents/base.py` |
| 3 | Добавить RuntimeError в `__call__()` | `agents/base.py` |
| 4 | Обновить TeamOrchestrator | `agents/orchestrator.py` |
| 5 | Создать AgentTestHarness | `testing/harness.py` |
| 6 | Обновить все тесты | `tests/agents/`, `tests/team/` |
| 7 | Документация | Migration guide |

**Изменения в BaseAgent:**

```python
class BaseAgent(ABC):

    # INTERNAL - только для orchestrator
    async def _process(
        self,
        input_data: Dict[str, Any],
        context: Optional[ExecutionContext] = None,
    ) -> AgentResult:
        """Internal execution. Called by TeamOrchestrator only."""
        return await self._execute(input_data, context)

    @abstractmethod
    async def _execute(
        self,
        input_data: Dict[str, Any],
        context: Optional[ExecutionContext] = None,
    ) -> AgentResult:
        """Subclass implementation."""
        pass

    # FORBIDDEN - raise error
    async def process(self, input_data: Dict[str, Any]) -> AgentResult:
        """DEPRECATED: Use team.run() instead."""
        raise RuntimeError(
            f"Direct call to {self.__class__.__name__}.process() is forbidden. "
            f"Use team.run() to ensure proper logging, reporting, and flow control."
        )

    def __call__(self, *args, **kwargs):
        """Forbid direct agent call."""
        raise RuntimeError(
            f"Direct agent call is forbidden. Use team.run() instead."
        )
```

**AgentTestHarness:**

```python
# llmteam/testing/harness.py

class AgentTestHarness:
    """Test harness for unit testing agents."""

    async def run_agent(
        self,
        agent: BaseAgent,
        input_data: Dict[str, Any],
        context: Dict = None,
    ) -> AgentResult:
        """Run agent in test mode (bypasses protection)."""
        return await agent._process(input_data, context)
```

---

## Phase 2: New Features (v5.1.0)

### 2.1 RFC-004: GroupOrchestrator (Week 5-6)

**Задачи:**

| # | Задача | Файлы |
|---|--------|-------|
| 1 | Создать GroupRole enum | `orchestration/group.py` |
| 2 | Создать TeamReport dataclass | `orchestration/reports.py` |
| 3 | Создать GroupReport dataclass | `orchestration/reports.py` |
| 4 | Создать GroupResult dataclass | `orchestration/reports.py` |
| 5 | Создать GroupOrchestrator класс | `orchestration/group.py` |
| 6 | Интегрировать с LLMGroup | `team/group.py` |
| 7 | Тесты | `tests/orchestration/test_group.py` |

**Структура файлов:**

```
llmteam/
├── orchestration/
│   ├── __init__.py
│   ├── group.py          # GroupOrchestrator, GroupRole
│   └── reports.py        # TeamReport, GroupReport, GroupResult
```

---

### 2.2 RFC-005: CONFIGURATOR Mode (Week 7-12)

**Задачи:**

| # | Задача | Неделя |
|---|--------|--------|
| 1 | Добавить CONFIGURATOR в OrchestratorMode | W7 |
| 2 | Создать ConfiguratorPrompts | W7 |
| 3 | Создать ConfigurationSession | W8 |
| 4 | Создать AgentSuggestion, TestRunResult | W8 |
| 5 | Реализовать analyze(), suggest() | W9 |
| 6 | Реализовать test_run() | W9 |
| 7 | Реализовать apply(), export_config() | W10 |
| 8 | Интегрировать team.configure() | W10 |
| 9 | Тестирование промптов | W11 |
| 10 | Документация и примеры | W12 |

**Структура файлов:**

```
llmteam/
├── agents/
│   ├── orchestrator.py   # + CONFIGURATOR mode
│   └── prompts.py        # + ConfiguratorPrompts
├── configuration/
│   ├── __init__.py
│   ├── session.py        # ConfigurationSession
│   └── models.py         # AgentSuggestion, TestRunResult
```

---

## Timeline

```
Week 1:  RFC-006 - Canvas → Engine (rename, restructure)
Week 2:  RFC-006 - Optional Engine (lazy imports, pyproject.toml, Core-only tests)
Week 3:  RFC-007 - Agent encapsulation (start)
Week 4:  RFC-007 - Agent encapsulation (continue)
Week 5:  RFC-007 - Tests, documentation
─────────────────────────────────────────────
         v5.0.0 RELEASE (Breaking Changes)
─────────────────────────────────────────────
Week 6:  RFC-004 - GroupOrchestrator (start)
Week 7:  RFC-004 - GroupOrchestrator (finish)
Week 8:  RFC-005 - CONFIGURATOR (mode, prompts)
Week 9:  RFC-005 - CONFIGURATOR (session, models)
Week 10: RFC-005 - CONFIGURATOR (analyze, suggest, test)
Week 11: RFC-005 - CONFIGURATOR (apply, integrate)
Week 12: RFC-005 - CONFIGURATOR (testing)
Week 13: RFC-005 - CONFIGURATOR (docs)
─────────────────────────────────────────────
         v5.1.0 RELEASE (New Features)
─────────────────────────────────────────────
```

**Итого: 13 недель (~3 месяца)**

---

## Checklist

### v5.0.0 Release Checklist

- [ ] **RFC-006: Canvas → Optional Engine**
  - [ ] Директория `canvas/` переименована в `engine/`
  - [ ] `runner.py` переименован в `engine.py`
  - [ ] Все классы переименованы по таблице
  - [ ] Внутренние imports обновлены
  - [ ] `pyproject.toml`: `[engine]` extra dependency
  - [ ] Lazy imports в `__init__.py` с ImportError
  - [ ] LLMTeam работает без Engine (simple flow)
  - [ ] Deprecation warnings для старых имён
  - [ ] Тесты Core-only проходят (без Engine)
  - [ ] Тесты Engine проходят
  - [ ] CHANGELOG обновлён

- [ ] **RFC-007: Agent Encapsulation**
  - [ ] `BaseAgent._process()` — internal method
  - [ ] `BaseAgent.process()` → RuntimeError
  - [ ] `BaseAgent.__call__()` → RuntimeError
  - [ ] `TeamOrchestrator` вызывает `_process()`
  - [ ] `AgentTestHarness` создан
  - [ ] Все тесты обновлены и проходят
  - [ ] Migration guide написан

### v5.1.0 Release Checklist

- [ ] **RFC-004: GroupOrchestrator**
  - [ ] `GroupRole.REPORT_COLLECTOR` работает
  - [ ] `TeamReport` собирается с каждого TeamOrchestrator
  - [ ] `GroupReport` агрегирует TeamReport'ы
  - [ ] `LLMGroup` использует GroupOrchestrator
  - [ ] Sequential и parallel execution работают
  - [ ] Тесты проходят

- [ ] **RFC-005: CONFIGURATOR Mode**
  - [ ] `OrchestratorMode.CONFIGURATOR` добавлен
  - [ ] `ConfigurationSession` со всеми методами
  - [ ] `team.configure()` работает
  - [ ] Промпты для analyze, suggest, test_analysis
  - [ ] `test_run()` выполняет реальный запуск
  - [ ] `export_config()` / `LLMTeam.from_config()` работают
  - [ ] Тесты полного flow
  - [ ] Документация с примерами

---

## Migration Guide (для пользователей)

### Imports (v5.0.0)

```python
# BEFORE (v4.x)
from llmteam.canvas import SegmentRunner, SegmentDefinition
from llmteam import SegmentRunner

# AFTER (v5.0)
from llmteam.engine import ExecutionEngine, WorkflowDefinition
from llmteam import ExecutionEngine

# Deprecated (работает с warning)
from llmteam import SegmentRunner  # DeprecationWarning
```

### Agent Calls (v5.0.0)

```python
# BEFORE (v4.x) - работало, но неправильно
agent = team.get_agent("writer")
result = await agent.process({"text": "..."})  # Прямой вызов

# AFTER (v5.0) - правильно
result = await team.run({"text": "..."})  # Через orchestrator

# Для тестов
from llmteam.testing import AgentTestHarness
harness = AgentTestHarness()
result = await harness.run_agent(agent, {"text": "..."})
```

### GroupOrchestrator (v5.1.0)

```python
# NEW in v5.1
from llmteam import LLMGroup

group = LLMGroup(teams=[team1, team2])
result = await group.run({"query": "..."}, parallel=True)

print(result.report.summary)
for tr in result.report.team_reports:
    print(f"{tr.team_id}: {tr.duration_ms}ms")
```

### CONFIGURATOR (v5.1.0)

```python
# NEW in v5.1
team = LLMTeam()

session = await team.configure(
    task="Generate social media posts from news articles"
)

print(session.suggested_agents)
test = await session.test_run({"article": "..."})
print(test.analysis)

await session.apply()
result = await team.run({"article": "..."})
```

---

## Риски и митигация

| Риск | Митигация |
|------|-----------|
| Сломанные imports (RFC-006) | Deprecation warnings + 1 версия переходного периода |
| Сломанный agent.process() (RFC-007) | Clear error message с инструкцией |
| Плохие предложения LLM (RFC-005) | Обязательный test_run() перед apply() |
| Высокие затраты токенов (RFC-005) | Документировать, добавить кэширование в будущем |

---

## Ответственные

| RFC | Ответственный | Reviewer |
|-----|---------------|----------|
| RFC-006 | @Developer | @Architect |
| RFC-007 | @Developer | @Security |
| RFC-004 | @Developer | @Architect |
| RFC-005 | @Developer | @PM, @Architect |

---

**Статус:** Готов к реализации

**Начало:** После утверждения

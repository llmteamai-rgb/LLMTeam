# RFC-007: Agent Encapsulation — Запрет прямого доступа в runtime

**Дата:** 2026-01-21  
**Статус:** DRAFT  
**Автор:** @Architect + @Security  
**Приоритет:** P1

---

## TL;DR

| Аспект | Значение |
|--------|----------|
| **Изменение** | Запретить прямой вызов `agent.process()` |
| **Альтернатива** | Только через `team.run()` → `orchestrator` → `agent._process()` |
| **Цель** | Гарантировать логирование, отчёты, flow control |
| **Breaking Changes** | Да (если кто-то вызывал agent.process() напрямую) |

---

## 1. Мотивация

### 1.1 Проблема

Сейчас агенты доступны напрямую:

```python
team = LLMTeam()
agent = team.add_agent({"role": "writer", ...})

# Можно обойти orchestrator
result = await agent.process({"topic": "AI"})  # ❌ Работает!
```

**Последствия обхода:**
- Нет логирования вызова
- Нет отчёта в TeamReport
- Нарушен flow (агент вызван вне очереди)
- Нет метрик времени выполнения
- Нет error handling от orchestrator

### 1.2 Аналогия

Это как если бы в компании сотрудники выполняли работу, минуя менеджера:

```
С orchestrator:
  Client → Manager → Worker → Manager → Report → Client
  
Без orchestrator (текущее):
  Client → Worker напрямую (никто не знает, что работа выполнена)
```

### 1.3 Цель

**Единственный путь к агенту — через orchestrator.**

```
✅ team.run() → orchestrator.execute() → agent._process()
❌ agent.process() — запрещено
```

---

## 2. Решение

### 2.1 Protected Method

```python
class BaseAgent(ABC):
    """Базовый класс агента с защищённым выполнением."""
    
    async def _process(
        self,
        input_data: Dict[str, Any],
        context: Optional[Dict] = None,
    ) -> AgentResult:
        """
        INTERNAL: Выполнение агента.
        
        Вызывается ТОЛЬКО из TeamOrchestrator.
        Не вызывать напрямую!
        
        Args:
            input_data: Входные данные
            context: Контекст выполнения (от orchestrator)
        
        Returns:
            AgentResult
        """
        # Реальная логика обработки
        return await self._execute(input_data, context)
    
    @abstractmethod
    async def _execute(
        self,
        input_data: Dict[str, Any],
        context: Optional[Dict] = None,
    ) -> AgentResult:
        """Реализация в подклассах."""
        pass
    
    async def process(
        self,
        input_data: Dict[str, Any],
    ) -> AgentResult:
        """
        PUBLIC: Запрещённый метод.
        
        Raises:
            RuntimeError: Всегда. Используйте team.run()
        """
        raise RuntimeError(
            f"Direct call to {self.__class__.__name__}.process() is not allowed. "
            f"Use team.run() instead to ensure proper logging, reporting, and flow control."
        )
```

### 2.2 Orchestrator как единственный caller

```python
class TeamOrchestrator:
    """Orchestrator с эксклюзивным доступом к агентам."""
    
    async def execute(self, input_data: Dict[str, Any]) -> RunResult:
        """Выполнить команду."""
        
        for step in execution_plan:
            agent = self._team._agents[step.agent_role]
            
            # Orchestrator вызывает _process напрямую
            # (он имеет право, т.к. это internal API)
            start_time = time.time()
            
            try:
                result = await agent._process(
                    input_data=step_input,
                    context=self._create_context(step),
                )
                
                # Логирование
                self._log_agent_execution(agent, result, start_time)
                
                # Отчёт
                self._add_to_report(agent, result)
                
            except Exception as e:
                # Error handling
                self._handle_error(agent, e)
                raise
        
        return self._finalize_result()
```

### 2.3 Flow гарантии

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   User Code                                                     │
│       │                                                         │
│       │  team.run(input)                                       │
│       ▼                                                         │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │ LLMTeam                                                 │  │
│   │     │                                                   │  │
│   │     │  _orchestrator.execute(input)                    │  │
│   │     ▼                                                   │  │
│   │ ┌─────────────────────────────────────────────────────┐│  │
│   │ │ TeamOrchestrator                                    ││  │
│   │ │                                                     ││  │
│   │ │   for agent in flow:                               ││  │
│   │ │       ┌──────────────────────────────────────────┐ ││  │
│   │ │       │ 1. Log: "Starting agent X"               │ ││  │
│   │ │       │ 2. result = agent._process(data)         │ ││  │
│   │ │       │ 3. Log: "Agent X completed in 150ms"     │ ││  │
│   │ │       │ 4. Add to TeamReport                     │ ││  │
│   │ │       │ 5. Pass output to next agent             │ ││  │
│   │ │       └──────────────────────────────────────────┘ ││  │
│   │ │                                                     ││  │
│   │ │   return RunResult + TeamReport                    ││  │
│   │ └─────────────────────────────────────────────────────┘│  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│   ❌ agent.process(input)  →  RuntimeError                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Гарантии

### 3.1 Что гарантирует encapsulation

| Гарантия | Как обеспечивается |
|----------|-------------------|
| **Логирование** | Orchestrator логирует каждый вызов |
| **Отчёты** | Каждый agent._process() → AgentReport |
| **Flow control** | Orchestrator определяет порядок |
| **Метрики** | Время каждого агента измеряется |
| **Error handling** | Централизованная обработка ошибок |
| **Context** | Агент получает контекст от orchestrator |

### 3.2 Чего НЕ гарантирует

| Не гарантируется | Почему |
|------------------|--------|
| Защита от reflection | Python позволяет вызвать _process |
| Защита от monkey patching | Python это Python |

**Принцип:** "We're all consenting adults here" — защита от случайного, не от намеренного.

---

## 4. API изменения

### 4.1 BaseAgent

```python
class BaseAgent(ABC):
    """Базовый класс агента."""
    
    def __init__(self, config: AgentConfig):
        self._config = config
        self._role = config.role
    
    # === Public (read-only) ===
    
    @property
    def role(self) -> str:
        """Роль агента."""
        return self._role
    
    @property
    def config(self) -> AgentConfig:
        """Конфигурация агента (read-only)."""
        return self._config
    
    def describe(self) -> Dict[str, Any]:
        """Описание агента для инспекции."""
        return {
            "role": self._role,
            "type": self._config.type,
            "model": self._config.model,
        }
    
    # === Protected (orchestrator only) ===
    
    async def _process(
        self,
        input_data: Dict[str, Any],
        context: Optional[ExecutionContext] = None,
    ) -> AgentResult:
        """
        INTERNAL: Выполнение агента.
        
        Не вызывать напрямую! Используйте team.run().
        """
        return await self._execute(input_data, context)
    
    @abstractmethod
    async def _execute(
        self,
        input_data: Dict[str, Any],
        context: Optional[ExecutionContext] = None,
    ) -> AgentResult:
        """Реализация в подклассах."""
        pass
    
    # === Forbidden ===
    
    async def process(self, input_data: Dict[str, Any]) -> AgentResult:
        """DEPRECATED: Используйте team.run()."""
        raise RuntimeError(
            f"Direct agent.process() is forbidden. Use team.run() instead."
        )
    
    def __call__(self, *args, **kwargs):
        """Запретить вызов как функции."""
        raise RuntimeError(
            f"Direct agent call is forbidden. Use team.run() instead."
        )
```

### 4.2 LLMTeam

```python
class LLMTeam:
    """Команда с защищённым доступом к агентам."""
    
    def get_agent(self, role: str) -> Optional[BaseAgent]:
        """
        Получить агента для инспекции.
        
        NOTE: Вызов agent.process() запрещён.
        Для выполнения используйте team.run().
        
        Args:
            role: Роль агента
        
        Returns:
            Агент (только для чтения конфигурации)
        """
        return self._agents.get(role)
    
    def list_agents(self) -> List[str]:
        """Список ролей агентов."""
        return list(self._agents.keys())
    
    def describe_agents(self) -> Dict[str, Dict]:
        """Описание всех агентов."""
        return {role: agent.describe() for role, agent in self._agents.items()}
```

---

## 5. Migration Guide

### 5.1 Для пользователей

```python
# BEFORE (работало, но неправильно)
team = LLMTeam()
agent = team.add_agent({"role": "writer", ...})
result = await agent.process({"topic": "AI"})  # Прямой вызов

# AFTER (правильно)
team = LLMTeam()
team.add_agent({"role": "writer", ...})
result = await team.run({"topic": "AI"})  # Через orchestrator
```

### 5.2 Для получения информации об агенте

```python
# Инспекция агента (разрешено)
agent = team.get_agent("writer")
print(agent.role)
print(agent.config)
print(agent.describe())

# Выполнение агента (запрещено)
await agent.process({})  # ❌ RuntimeError
```

---

## 6. Оценка рисков

### 6.1 Матрица рисков

| Риск | Вероятность | Влияние | Итог | Митигация |
|------|-------------|---------|------|-----------|
| Сломан код пользователей | Средняя | Высокое | HIGH | Deprecation period + clear error message |
| Сложнее отлаживать | Низкая | Среднее | LOW | agent.describe(), логи orchestrator |
| Невозможно использовать agent standalone | Средняя | Среднее | MEDIUM | Документировать как design decision |
| Обход через _process | Низкая | Низкое | LOW | "Consenting adults" — не защищаемся |

### 6.2 Оценка рисков: **СРЕДНИЙ**

Основной риск — сломать существующий код. Митигация: хорошее error message с инструкцией.

---

## 7. Оценка целесообразности

### 7.1 Преимущества

| Преимущество | Вес |
|--------------|-----|
| Гарантия логирования всех операций | ⭐⭐⭐⭐ |
| Гарантия отчётов | ⭐⭐⭐⭐ |
| Единый flow control | ⭐⭐⭐ |
| Централизованный error handling | ⭐⭐⭐ |
| Чистая архитектура | ⭐⭐ |

### 7.2 Недостатки

| Недостаток | Вес |
|------------|-----|
| Breaking change | ⭐⭐⭐ |
| Меньше гибкости для продвинутых пользователей | ⭐⭐ |
| Сложнее unit-тестировать отдельные агенты | ⭐⭐ |

### 7.3 Вердикт: **ВЫСОКО ЦЕЛЕСООБРАЗНО**

**ROI:** Высокий. Архитектурная чистота + гарантии для production.

---

## 8. Тестирование агентов

### 8.1 Проблема

Как тестировать агента отдельно, если process() запрещён?

### 8.2 Решение: TestHarness

```python
from llmteam.testing import AgentTestHarness

# Специальный класс для тестирования
harness = AgentTestHarness()

# Создаём агента
agent = LLMAgent(config=AgentConfig(role="writer", ...))

# Тестируем через harness (он имеет доступ к _process)
result = await harness.run_agent(agent, {"topic": "AI"})

assert result.success
assert "AI" in result.output
```

```python
# llmteam/testing/harness.py

class AgentTestHarness:
    """
    Тестовый harness для агентов.
    
    Позволяет вызывать agent._process() в тестах,
    сохраняя запрет в production коде.
    """
    
    async def run_agent(
        self,
        agent: BaseAgent,
        input_data: Dict[str, Any],
        context: Dict = None,
    ) -> AgentResult:
        """
        Выполнить агента в тестовом режиме.
        
        NOTE: Только для тестов! В production используйте team.run().
        """
        return await agent._process(input_data, context)
    
    async def run_agent_with_mock_llm(
        self,
        agent: BaseAgent,
        input_data: Dict[str, Any],
        mock_response: str,
    ) -> AgentResult:
        """Выполнить с мокированным LLM."""
        with patch_llm(mock_response):
            return await agent._process(input_data)
```

---

## 9. План реализации

| Неделя | Задача |
|--------|--------|
| W1 | Переименовать process() → _process() в BaseAgent |
| W1 | Добавить RuntimeError в process() |
| W2 | Обновить TeamOrchestrator для вызова _process() |
| W2 | Создать AgentTestHarness |
| W3 | Обновить все тесты |
| W3 | Документация + migration guide |

**Общее время: 3 недели**

---

## 10. Зависимости

- **Зависит от:** RFC-006 (RuntimeEngine) — опционально
- **Блокирует:** Ничего
- **Рекомендуется вместе с:** RFC-005 (CONFIGURATOR)

---

## 11. Definition of Done

- [ ] BaseAgent._process() — internal method
- [ ] BaseAgent.process() → RuntimeError
- [ ] BaseAgent.__call__() → RuntimeError
- [ ] TeamOrchestrator вызывает _process()
- [ ] AgentTestHarness для тестов
- [ ] Все тесты обновлены
- [ ] Документация + migration guide
- [ ] Error message с инструкцией

---

**Рекомендация: ПРИНЯТЬ**

Средний риск, высокая целесообразность. Критично для production-ready библиотеки.

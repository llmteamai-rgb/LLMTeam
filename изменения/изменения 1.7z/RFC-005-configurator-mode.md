# RFC-005: TeamOrchestrator CONFIGURATOR — Основной способ настройки команды

**Дата:** 2026-01-21  
**Статус:** DRAFT  
**Автор:** @Architect + @PM  
**Приоритет:** P1

---

## TL;DR

| Аспект | Значение |
|--------|----------|
| **Изменение** | Добавить CONFIGURATOR mode в TeamOrchestrator |
| **Назначение** | Основной способ настройки команды через LLM |
| **API** | `team.configure(task)` → ConfigurationSession |
| **Breaking Changes** | Нет (новый функционал) |

---

## 1. Мотивация

### 1.1 Текущее состояние

Настройка команды требует ручной работы:

```python
# Пользователь должен знать:
# - Какие агенты нужны
# - Как их настроить
# - Какой flow использовать

team = LLMTeam()
team.add_agent({"role": "???", "type": "???", "prompt": "???"})
team.add_agent({"role": "???", "type": "???", "prompt": "???"})
team.set_flow("??? -> ???")

# Итеративный процесс проб и ошибок
result = await team.run(test_input)
# Не работает → меняем промпты → снова тестируем
# Цикл 10-20 раз
```

**Барьер:** Требует экспертизы в prompt engineering.

### 1.2 Предлагаемое решение

CONFIGURATOR mode — LLM помогает настроить команду:

```python
team = LLMTeam()

# Описываем задачу на естественном языке
session = await team.configure(
    task="Генерировать посты для LinkedIn из пресс-релизов"
)

# LLM предлагает состав команды
print(session.suggested_agents)
# [extractor, writer, polisher]

# Тестируем
test = await session.test_run({"press_release": "..."})
print(test.analysis)
# "Результат хороший. Рекомендация: добавить CTA"

# Применяем
await session.apply()

# Готово к работе
result = await team.run({"press_release": "..."})
```

---

## 2. Архитектура

### 2.1 Режимы TeamOrchestrator

```python
class OrchestratorMode(Flag):
    """Режимы работы TeamOrchestrator."""
    
    # === Design-time ===
    CONFIGURATOR = auto()   # Помощь в настройке команды
    
    # === Run-time ===
    SUPERVISOR = auto()     # Наблюдение за выполнением
    REPORTER = auto()       # Генерация отчётов
    # Будущие режимы:
    # ROUTER = auto()       # Adaptive routing (P3)
    # RECOVERY = auto()     # Обработка ошибок (P3)
    
    # === Presets ===
    PASSIVE = SUPERVISOR | REPORTER
    ASSISTED = CONFIGURATOR | PASSIVE
```

### 2.2 Жизненный цикл команды

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   DESIGN-TIME (CONFIGURATOR)          RUN-TIME (SUPERVISOR)    │
│                                                                 │
│   ┌──────────────────────┐           ┌──────────────────────┐  │
│   │                      │           │                      │  │
│   │  task ──► analyze    │           │  input ──► execute   │  │
│   │           suggest    │  apply()  │            report    │  │
│   │           test  ─────┼───────────┼──►                   │  │
│   │           iterate    │           │  ◄────── output      │  │
│   │                      │           │                      │  │
│   └──────────────────────┘           └──────────────────────┘  │
│                                                                 │
│   ConfigurationSession                LLMTeam.run()            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.3 ConfigurationSession

```python
@dataclass
class ConfigurationSession:
    """Сессия настройки команды."""
    
    session_id: str
    team: "LLMTeam"
    
    # Задача
    task: str
    constraints: Dict[str, Any]
    
    # Анализ
    task_analysis: Optional[str] = None
    
    # Предложения
    suggested_agents: List[AgentSuggestion] = field(default_factory=list)
    suggested_flow: Optional[str] = None
    
    # Текущая конфигурация (после правок)
    current_agents: List[Dict] = field(default_factory=list)
    current_flow: Optional[str] = None
    
    # Тестовые запуски
    test_runs: List[TestRunResult] = field(default_factory=list)
    
    # Состояние
    state: SessionState = SessionState.CREATED
    
    # === Методы ===
    
    async def analyze(self) -> str:
        """Анализ задачи через LLM."""
        pass
    
    async def suggest(self) -> Dict:
        """Предложить состав команды."""
        pass
    
    def add_agent(self, role: str, type: str, prompt: str, **config):
        """Добавить агента."""
        pass
    
    def modify_agent(self, role: str, **changes):
        """Изменить агента."""
        pass
    
    def remove_agent(self, role: str):
        """Удалить агента."""
        pass
    
    def set_flow(self, flow: str):
        """Задать flow."""
        pass
    
    async def test_run(self, input_data: Dict) -> TestRunResult:
        """Тестовый запуск с анализом."""
        pass
    
    async def apply(self):
        """Применить конфигурацию к команде."""
        pass
    
    def export_config(self) -> Dict:
        """Экспортировать конфигурацию."""
        pass


class SessionState(Enum):
    CREATED = "created"
    ANALYZING = "analyzing"
    SUGGESTING = "suggesting"
    CONFIGURING = "configuring"
    TESTING = "testing"
    READY = "ready"
    APPLIED = "applied"


@dataclass
class AgentSuggestion:
    """Предложение агента от CONFIGURATOR."""
    role: str
    type: str  # "llm", "rag", "kag"
    purpose: str
    prompt_template: str
    reasoning: str


@dataclass
class TestRunResult:
    """Результат тестового запуска."""
    test_id: str
    input_data: Dict
    output: Dict
    agent_outputs: Dict[str, Any]
    duration_ms: int
    success: bool
    
    # Анализ от LLM
    analysis: str
    issues: List[str]
    recommendations: List[str]
```

### 2.4 Промпты CONFIGURATOR

```python
class ConfiguratorPrompts:
    
    TASK_ANALYSIS = """
Analyze the user's task:

Task: {task}
Constraints: {constraints}

Extract:
1. Main goal
2. Input type
3. Expected output
4. Sub-tasks needed
5. Complexity (simple/moderate/complex)

Return JSON:
{{
    "main_goal": "...",
    "input_type": "...",
    "output_type": "...",
    "sub_tasks": ["...", "..."],
    "complexity": "simple|moderate|complex"
}}
"""

    TEAM_SUGGESTION = """
Based on analysis, suggest an AI agent team.

Analysis: {task_analysis}

Agent types available:
- LLM: text generation, reasoning
- RAG: retrieval + generation
- KAG: knowledge graph + generation

For each agent provide:
- role: unique name
- type: llm/rag/kag
- purpose: what it does
- prompt_template: initial prompt
- reasoning: why needed

Return JSON:
{{
    "agents": [...],
    "flow": "agent1 -> agent2 -> agent3",
    "reasoning": "..."
}}
"""

    TEST_ANALYSIS = """
Analyze test run results.

Config: {team_config}
Input: {test_input}
Agent outputs: {agent_outputs}
Final output: {final_output}
Duration: {duration_ms}ms

Assess:
1. Does output match goal?
2. Did each agent work correctly?
3. Issues found?
4. Improvements needed?

Return JSON:
{{
    "overall": "success|partial|failure",
    "issues": [...],
    "recommendations": [...],
    "ready_for_production": true|false,
    "summary": "..."
}}
"""
```

---

## 3. API

### 3.1 LLMTeam Extensions

```python
class LLMTeam:
    
    async def configure(
        self,
        task: str,
        constraints: Dict[str, Any] = None,
    ) -> ConfigurationSession:
        """
        Начать настройку команды через CONFIGURATOR.
        
        Args:
            task: Описание задачи на естественном языке
            constraints: Ограничения (тон, длина, формат)
        
        Returns:
            ConfigurationSession для итеративной настройки
        
        Example:
            session = await team.configure(
                task="Generate social media posts from news",
                constraints={"tone": "professional", "length": "<300"}
            )
            
            # Смотрим предложения
            print(session.suggested_agents)
            
            # Тестируем
            test = await session.test_run({"news": "..."})
            
            # Применяем
            await session.apply()
        """
        # Включаем CONFIGURATOR mode
        self._orchestrator.enable_mode(OrchestratorMode.CONFIGURATOR)
        
        # Создаём сессию
        session = ConfigurationSession(
            session_id=str(uuid.uuid4()),
            team=self,
            task=task,
            constraints=constraints or {},
        )
        
        # Анализируем и предлагаем
        await session.analyze()
        await session.suggest()
        
        return session
    
    @classmethod
    def from_config(cls, config: Dict) -> "LLMTeam":
        """
        Создать команду из экспортированной конфигурации.
        
        Args:
            config: Результат session.export_config()
        
        Returns:
            Готовая к работе LLMTeam
        """
        team = cls(team_id=config.get("team_id"))
        
        for agent_config in config["agents"]:
            team.add_agent(agent_config)
        
        if config.get("flow"):
            team.set_flow(config["flow"])
        
        return team
```

### 3.2 TeamOrchestrator Extensions

```python
class TeamOrchestrator:
    
    def __init__(self, team: "LLMTeam", config: OrchestratorConfig = None):
        self._team = team
        self._config = config or OrchestratorConfig()
        self._modes = OrchestratorMode.PASSIVE  # Default
        self._llm = None  # Lazy init
    
    def enable_mode(self, mode: OrchestratorMode):
        """Включить режим."""
        self._modes |= mode
    
    def disable_mode(self, mode: OrchestratorMode):
        """Выключить режим."""
        self._modes &= ~mode
    
    def has_mode(self, mode: OrchestratorMode) -> bool:
        """Проверить режим."""
        return bool(self._modes & mode)
    
    # === CONFIGURATOR methods ===
    
    async def analyze_task(self, task: str, constraints: Dict) -> Dict:
        """Анализ задачи через LLM."""
        prompt = ConfiguratorPrompts.TASK_ANALYSIS.format(
            task=task,
            constraints=json.dumps(constraints),
        )
        response = await self._get_llm().complete(prompt)
        return json.loads(response)
    
    async def suggest_team(self, analysis: Dict) -> Dict:
        """Предложить команду через LLM."""
        prompt = ConfiguratorPrompts.TEAM_SUGGESTION.format(
            task_analysis=json.dumps(analysis, indent=2),
        )
        response = await self._get_llm().complete(prompt)
        return json.loads(response)
    
    async def analyze_test(
        self,
        config: Dict,
        input_data: Dict,
        agent_outputs: Dict,
        final_output: Any,
        duration_ms: int,
    ) -> Dict:
        """Анализ тестового запуска через LLM."""
        prompt = ConfiguratorPrompts.TEST_ANALYSIS.format(
            team_config=json.dumps(config, indent=2),
            test_input=json.dumps(input_data, indent=2),
            agent_outputs=json.dumps(agent_outputs, indent=2),
            final_output=json.dumps(final_output, indent=2),
            duration_ms=duration_ms,
        )
        response = await self._get_llm().complete(prompt)
        return json.loads(response)
    
    def _get_llm(self):
        """Lazy init LLM client."""
        if self._llm is None:
            self._llm = create_llm_client(self._config.model)
        return self._llm
```

---

## 4. Пример полного flow

```python
from llmteam import LLMTeam

# 1. Создаём пустую команду
team = LLMTeam(team_id="content_team")

# 2. Запускаем CONFIGURATOR
session = await team.configure(
    task="Генерировать посты для LinkedIn из пресс-релизов компании",
    constraints={
        "tone": "professional",
        "length": "< 300 слов",
        "include_hashtags": True,
    }
)

# 3. Смотрим, что предложил LLM
print(f"State: {session.state}")  # CONFIGURING

print("Suggested agents:")
for agent in session.suggested_agents:
    print(f"  {agent.role} ({agent.type}): {agent.purpose}")
# extractor (llm): Извлечь ключевые факты
# writer (llm): Написать пост
# polisher (llm): Добавить хэштеги и CTA

print(f"Suggested flow: {session.suggested_flow}")
# "extractor -> writer -> polisher"

# 4. Можем скорректировать
session.modify_agent("writer", prompt="Write in first person plural (we, our)...")

# 5. Тестируем
test = await session.test_run({
    "press_release": """
    ACME Corp сегодня объявила о запуске новой AI-платформы,
    которая поможет бизнесу автоматизировать рутинные задачи...
    """
})

print(f"Output: {test.output}")
print(f"Success: {test.success}")
print(f"Analysis: {test.analysis}")
# "Пост хороший, но нет призыва к действию в конце"

print(f"Recommendations: {test.recommendations}")
# ["Добавить CTA: 'Узнайте больше на нашем сайте'"]

# 6. Корректируем по рекомендациям
session.modify_agent("polisher", prompt="...and add CTA at the end")

# 7. Тестируем ещё раз
test2 = await session.test_run({...})
print(f"Ready for production: {test2.success}")  # True

# 8. Применяем конфигурацию
await session.apply()
print(f"State: {session.state}")  # APPLIED

# 9. Экспортируем для повторного использования
config = session.export_config()
with open("linkedin_team.json", "w") as f:
    json.dump(config, f)

# 10. Серийная работа
for pr in press_releases:
    result = await team.run({"press_release": pr})
    publish_to_linkedin(result.final_output)
```

---

## 5. Оценка рисков

### 5.1 Матрица рисков

| Риск | Вероятность | Влияние | Итог | Митигация |
|------|-------------|---------|------|-----------|
| LLM даёт плохие предложения | Средняя | Среднее | MEDIUM | Улучшать промпты, добавить примеры |
| Пользователь слепо доверяет | Средняя | Среднее | MEDIUM | Обязательное тестирование |
| Высокие затраты токенов | Высокая | Низкое | MEDIUM | Кэширование, batch запросы |
| Сложность отладки | Низкая | Среднее | LOW | Логирование промптов/ответов |
| Несовместимость промптов | Низкая | Высокое | MEDIUM | Версионирование промптов |

### 5.2 Оценка рисков: **СРЕДНИЙ**

Основной риск — качество предложений LLM. Митигация: обязательное тестирование перед apply().

---

## 6. Оценка целесообразности

### 6.1 Преимущества

| Преимущество | Вес |
|--------------|-----|
| Снижает барьер входа в 10+ раз | ⭐⭐⭐⭐⭐ |
| Ускоряет настройку (часы → минуты) | ⭐⭐⭐⭐ |
| Встроенное тестирование | ⭐⭐⭐ |
| Анализ и рекомендации от LLM | ⭐⭐⭐ |
| Экспорт/импорт конфигураций | ⭐⭐ |

### 6.2 Недостатки

| Недостаток | Вес |
|------------|-----|
| Затраты на LLM токены | ⭐⭐ |
| Зависимость от качества промптов | ⭐⭐ |
| Дополнительная сложность | ⭐ |

### 6.3 Вердикт: **ВЫСОКО ЦЕЛЕСООБРАЗНО**

**ROI:** Очень высокий. Это killer feature, которая радикально упрощает использование библиотеки.

---

## 7. План реализации

| Неделя | Задача |
|--------|--------|
| W1 | OrchestratorMode, ConfiguratorPrompts |
| W2 | ConfigurationSession, AgentSuggestion |
| W3 | TeamOrchestrator CONFIGURATOR methods |
| W4 | team.configure() интеграция |
| W5 | Тестирование, улучшение промптов |
| W6 | Документация, примеры |

**Общее время: 6 недель**

---

## 8. Зависимости

- **Зависит от:** RFC-006 (RuntimeEngine) — для test_run
- **Блокирует:** Ничего
- **Рекомендуется после:** RFC-007 (Agent encapsulation)

---

## 9. Definition of Done

- [ ] OrchestratorMode.CONFIGURATOR реализован
- [ ] ConfigurationSession со всеми методами
- [ ] team.configure() работает
- [ ] Промпты для analyze, suggest, test_analysis
- [ ] test_run выполняет реальный запуск
- [ ] export_config / LLMTeam.from_config работают
- [ ] Тесты: полный flow от configure до apply
- [ ] Документация с примерами

---

**Рекомендация: ПРИНЯТЬ**

Средний риск, очень высокая целесообразность. Ключевая feature для adoption.

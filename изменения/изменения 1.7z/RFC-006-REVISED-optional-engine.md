# RFC-006 REVISED: Canvas как опциональный модуль (Engine)

**Дата:** 2026-01-21
**Статус:** REVISED
**Приоритет:** P0

---

## TL;DR

| Аспект | Значение |
|--------|----------|
| **Изменение** | Сделать Canvas опциональным модулем `llmteam[engine]` |
| **Core** | LLMTeam + Orchestration работают без Canvas |
| **Optional** | DAG workflows, parallel, human tasks — через `engine/` |
| **Breaking Changes** | Да (imports, зависимости) |

---

## 1. Мотивация

### 1.1 Текущая проблема

Canvas тесно связан с core:
- Установка `llmteam` тянет весь Canvas
- Многим пользователям Canvas не нужен
- Увеличивает размер пакета и сложность

### 1.2 Цель

**Два режима использования:**

```python
# Режим 1: Простой (без Canvas/Engine)
pip install llmteam

from llmteam import LLMTeam
team = LLMTeam(agents=[...], flow="a -> b -> c")
result = await team.run(input_data)

# Режим 2: С workflow engine
pip install llmteam[engine]

from llmteam.engine import ExecutionEngine, WorkflowDefinition
engine = ExecutionEngine()
result = await engine.run(workflow, input_data, runtime)
```

---

## 2. Архитектура

### 2.1 Разделение модулей

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   llmteam (CORE) — всегда установлен                           │
│                                                                 │
│   ├── agents/          LLMAgent, RAGAgent, KAGAgent            │
│   │   ├── base.py      BaseAgent                               │
│   │   ├── orchestrator.py  TeamOrchestrator                    │
│   │   └── report.py    AgentReport                             │
│   │                                                             │
│   ├── team/            LLMTeam, LLMGroup                       │
│   │   ├── team.py      Команда с простым flow                  │
│   │   └── group.py     Группа команд                           │
│   │                                                             │
│   ├── orchestration/   GroupOrchestrator                       │
│   ├── escalation/      Эскалация                               │
│   ├── mining/          Process mining                          │
│   ├── providers/       LLM провайдеры                          │
│   └── runtime/         RuntimeContext (уже есть)               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   llmteam[engine] (OPTIONAL) — pip install llmteam[engine]     │
│                                                                 │
│   └── engine/          Workflow execution                      │
│       ├── engine.py    ExecutionEngine (бывший SegmentRunner)  │
│       ├── models.py    WorkflowDefinition, ExecutionResult     │
│       ├── catalog.py   StepCatalog                             │
│       ├── validation.py                                        │
│       └── handlers/    Step handlers                           │
│           ├── llm_handler.py                                   │
│           ├── team_handler.py                                  │
│           ├── http_handler.py                                  │
│           ├── transform_handler.py                             │
│           ├── condition_handler.py                             │
│           ├── parallel_handler.py                              │
│           ├── human_handler.py                                 │
│           └── subworkflow_handler.py                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Что входит в Core vs Engine

| Функционал | Core | Engine |
|------------|------|--------|
| LLMTeam с агентами | ✅ | — |
| Простой flow (`"a -> b -> c"`) | ✅ | — |
| TeamOrchestrator (PASSIVE/ROUTER) | ✅ | — |
| GroupOrchestrator | ✅ | — |
| AgentReport | ✅ | — |
| LLM/RAG/KAG агенты | ✅ | — |
| Escalation | ✅ | — |
| DAG workflows с условиями | — | ✅ |
| Parallel split/join | — | ✅ |
| Human-in-the-loop | — | ✅ |
| Subworkflows | — | ✅ |
| HTTP actions | — | ✅ |
| Transform steps | — | ✅ |
| Pause/Resume | — | ✅ |
| Step middleware | — | ✅ |

### 2.3 Простой flow в Core

Core поддерживает простой flow без Engine:

```python
# Core: линейный flow через orchestrator
team = LLMTeam(
    agents=[
        {"type": "llm", "role": "analyzer", "prompt": "..."},
        {"type": "llm", "role": "writer", "prompt": "..."},
    ],
    flow="analyzer -> writer"  # Простой линейный flow
)

# TeamOrchestrator выполняет последовательно
result = await team.run({"text": "..."})
```

**Поддерживаемый синтаксис flow в Core:**
- `"a -> b -> c"` — последовательный
- `"a -> b, a -> c"` — простое ветвление (все ветки выполняются)
- `None` — все агенты последовательно по порядку добавления

**НЕ поддерживается в Core (нужен Engine):**
- Условия (`condition="$.score > 0.8"`)
- Parallel split/join
- Циклы
- Human tasks

---

## 3. Реализация

### 3.1 pyproject.toml

```toml
[project]
name = "llmteam-ai"
version = "5.0.0"

dependencies = [
    "pydantic>=2.0",
    "httpx>=0.24",
    "openai>=1.0",  # Для LLM провайдеров
]

[project.optional-dependencies]
engine = [
    # Дополнительные зависимости для Engine (если нужны)
]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
    # ...
]
all = [
    "llmteam-ai[engine]",
]
```

### 3.2 Lazy imports в __init__.py

```python
# llmteam/__init__.py

__version__ = "5.0.0"

# === CORE (всегда доступно) ===
from llmteam.team.team import LLMTeam
from llmteam.team.group import LLMGroup
from llmteam.team.result import RunResult, RunStatus

from llmteam.agents.orchestrator import (
    TeamOrchestrator,
    OrchestratorMode,
    OrchestratorConfig,
)
from llmteam.agents.report import AgentReport

# === ENGINE (опционально) ===

def _check_engine_installed():
    """Check if engine module is available."""
    try:
        from llmteam import engine
        return True
    except ImportError:
        return False

# Lazy import для engine
def __getattr__(name):
    # Engine exports
    engine_exports = {
        "ExecutionEngine",
        "WorkflowDefinition",
        "ExecutionResult",
        "ExecutionStatus",
        "ExecutionSnapshot",
        "StepDefinition",
        "EdgeDefinition",
        "StepCatalog",
    }

    if name in engine_exports:
        try:
            from llmteam import engine
            return getattr(engine, name)
        except ImportError:
            raise ImportError(
                f"'{name}' requires the engine module. "
                f"Install with: pip install llmteam-ai[engine]"
            )

    # Deprecated Canvas names
    deprecated_mapping = {
        "SegmentRunner": "ExecutionEngine",
        "SegmentDefinition": "WorkflowDefinition",
        "SegmentResult": "ExecutionResult",
        "SegmentStatus": "ExecutionStatus",
    }

    if name in deprecated_mapping:
        import warnings
        new_name = deprecated_mapping[name]
        warnings.warn(
            f"{name} is deprecated, use {new_name} instead. "
            f"Also requires: pip install llmteam-ai[engine]",
            DeprecationWarning,
            stacklevel=2
        )
        try:
            from llmteam import engine
            return getattr(engine, new_name)
        except ImportError:
            raise ImportError(
                f"'{name}' requires the engine module. "
                f"Install with: pip install llmteam-ai[engine]"
            )

    raise AttributeError(f"module 'llmteam' has no attribute '{name}'")


# Явный экспорт для IDE автодополнения
__all__ = [
    # Core
    "LLMTeam",
    "LLMGroup",
    "RunResult",
    "RunStatus",
    "TeamOrchestrator",
    "OrchestratorMode",
    "OrchestratorConfig",
    "AgentReport",
    # Engine (optional, lazy)
    "ExecutionEngine",
    "WorkflowDefinition",
    "ExecutionResult",
    "ExecutionStatus",
    "StepDefinition",
    "EdgeDefinition",
    "StepCatalog",
]
```

### 3.3 engine/__init__.py

```python
# llmteam/engine/__init__.py

"""
LLMTeam Workflow Engine.

Optional module for DAG workflows, parallel execution, and advanced routing.

Install with: pip install llmteam-ai[engine]
"""

from llmteam.engine.engine import ExecutionEngine
from llmteam.engine.models import (
    WorkflowDefinition,
    StepDefinition,
    EdgeDefinition,
    ExecutionResult,
    ExecutionStatus,
    ExecutionSnapshot,
)
from llmteam.engine.catalog import StepCatalog
from llmteam.engine.validation import validate_workflow

__all__ = [
    "ExecutionEngine",
    "WorkflowDefinition",
    "StepDefinition",
    "EdgeDefinition",
    "ExecutionResult",
    "ExecutionStatus",
    "ExecutionSnapshot",
    "StepCatalog",
    "validate_workflow",
]
```

### 3.4 Graceful degradation в LLMTeam

```python
# llmteam/team/team.py

class LLMTeam:
    """
    Agent team container.

    Works without Engine for simple flows.
    For DAG workflows, install: pip install llmteam-ai[engine]
    """

    def __init__(
        self,
        team_id: str = None,
        agents: List[Dict] = None,
        flow: str = None,  # Simple flow: "a -> b -> c"
        workflow: "WorkflowDefinition" = None,  # Advanced: requires Engine
        **kwargs
    ):
        self._flow = flow
        self._workflow = workflow

        # Проверка: workflow требует Engine
        if workflow is not None:
            self._validate_engine_available()

    def _validate_engine_available(self):
        """Check if Engine is installed for advanced workflows."""
        try:
            from llmteam.engine import ExecutionEngine
        except ImportError:
            raise ImportError(
                "Advanced workflows require the engine module. "
                "Install with: pip install llmteam-ai[engine]"
            )

    async def run(self, input_data: Dict, **kwargs) -> RunResult:
        """
        Execute the team.

        Uses simple flow execution by default.
        Uses Engine if workflow is defined.
        """
        if self._workflow is not None:
            # Advanced: use Engine
            return await self._run_with_engine(input_data, **kwargs)
        else:
            # Simple: use orchestrator
            return await self._run_simple(input_data, **kwargs)

    async def _run_simple(self, input_data: Dict, **kwargs) -> RunResult:
        """Execute with simple flow (Core functionality)."""
        # TeamOrchestrator handles execution
        return await self._orchestrator.execute(input_data, **kwargs)

    async def _run_with_engine(self, input_data: Dict, **kwargs) -> RunResult:
        """Execute with Engine (requires llmteam[engine])."""
        from llmteam.engine import ExecutionEngine

        engine = ExecutionEngine()
        # ... execution logic
```

---

## 4. Миграция Canvas → Engine

### 4.1 Файловая структура

```
BEFORE:                          AFTER:
llmteam/                         llmteam/
├── canvas/                      ├── engine/           # Renamed
│   ├── __init__.py             │   ├── __init__.py   # Updated exports
│   ├── runner.py        →      │   ├── engine.py     # ExecutionEngine
│   ├── models.py        →      │   ├── models.py     # Workflow*, Execution*
│   ├── catalog.py              │   ├── catalog.py
│   ├── validation.py           │   ├── validation.py
│   └── handlers/               │   └── handlers/
│       └── ...                 │       └── ...
```

### 4.2 Переименования

| Before (Canvas) | After (Engine) |
|-----------------|----------------|
| `canvas/` | `engine/` |
| `runner.py` | `engine.py` |
| `SegmentRunner` | `ExecutionEngine` |
| `SegmentDefinition` | `WorkflowDefinition` |
| `SegmentResult` | `ExecutionResult` |
| `SegmentStatus` | `ExecutionStatus` |
| `SegmentSnapshot` | `ExecutionSnapshot` |
| `segment_id` | `workflow_id` |
| `CanvasError` | `EngineError` |

---

## 5. Примеры использования

### 5.1 Core (без Engine)

```python
# pip install llmteam-ai

from llmteam import LLMTeam

# Простая команда с линейным flow
team = LLMTeam(
    team_id="content",
    agents=[
        {"type": "rag", "role": "retriever", "collection": "docs"},
        {"type": "llm", "role": "writer", "prompt": "Write about: {context}"},
        {"type": "llm", "role": "editor", "prompt": "Edit: {draft}"},
    ],
    flow="retriever -> writer -> editor"
)

result = await team.run({"topic": "AI trends"})
print(result.output)
print(result.report)  # Отчёт от TeamOrchestrator
```

### 5.2 С Engine (advanced workflows)

```python
# pip install llmteam-ai[engine]

from llmteam import LLMTeam
from llmteam.engine import (
    ExecutionEngine,
    WorkflowDefinition,
    StepDefinition,
    EdgeDefinition,
)

# Создаём workflow с условиями и параллельностью
workflow = WorkflowDefinition(
    workflow_id="advanced_pipeline",
    steps=[
        StepDefinition(step_id="triage", type="llm_agent", config={...}),
        StepDefinition(step_id="billing", type="team", config={"team_ref": "billing_team"}),
        StepDefinition(step_id="technical", type="team", config={"team_ref": "tech_team"}),
        StepDefinition(step_id="parallel_research", type="parallel_split", config={...}),
        StepDefinition(step_id="human_approval", type="human_task", config={...}),
    ],
    edges=[
        EdgeDefinition(from_step="triage", to_step="billing", condition="$.category == 'billing'"),
        EdgeDefinition(from_step="triage", to_step="technical", condition="$.category == 'technical'"),
    ],
)

engine = ExecutionEngine()
result = await engine.run(workflow, input_data, runtime)
```

### 5.3 Ошибка при отсутствии Engine

```python
# pip install llmteam-ai  (без [engine])

from llmteam import ExecutionEngine  # ImportError!

# ImportError: 'ExecutionEngine' requires the engine module.
# Install with: pip install llmteam-ai[engine]
```

---

## 6. Тестирование

### 6.1 Структура тестов

```
tests/
├── core/                    # Тесты Core (без Engine)
│   ├── test_team.py
│   ├── test_orchestrator.py
│   └── test_simple_flow.py
│
├── engine/                  # Тесты Engine (требуют [engine])
│   ├── test_engine.py
│   ├── test_workflow.py
│   └── test_handlers.py
│
└── integration/             # Интеграционные тесты
    ├── test_core_only.py    # Работа без Engine
    └── test_with_engine.py  # Работа с Engine
```

### 6.2 Тест Core без Engine

```python
# tests/core/test_core_only.py

import pytest
from llmteam import LLMTeam

def test_simple_team_without_engine():
    """Core должен работать без Engine."""
    team = LLMTeam(
        team_id="test",
        agents=[
            {"type": "llm", "role": "writer", "prompt": "test"},
        ],
    )
    assert len(team) == 1

def test_engine_import_error_without_install():
    """ExecutionEngine должен требовать [engine]."""
    # Этот тест запускается в окружении без [engine]
    with pytest.raises(ImportError, match="requires the engine module"):
        from llmteam import ExecutionEngine
```

---

## 7. План реализации

| День | Задача |
|------|--------|
| D1 | Создать `engine/` директорию, перенести код из `canvas/` |
| D2 | Переименовать классы (Segment* → Workflow*/Execution*) |
| D3 | Обновить `__init__.py` с lazy imports |
| D4 | Обновить `pyproject.toml` с optional dependency |
| D5 | Обновить LLMTeam для работы без Engine |
| D6 | Перенести тесты, добавить тесты Core-only |
| D7 | Удалить `canvas/`, обновить документацию |

**Общее время: 1.5 недели**

---

## 8. Риски

| Риск | Вероятность | Влияние | Митигация |
|------|-------------|---------|-----------|
| Сломанные imports | Высокая | Среднее | Deprecation warnings + clear errors |
| Core не работает без Engine | Средняя | Высокое | Тесты Core-only |
| Путаница что где | Средняя | Низкое | Документация |

---

## 9. Definition of Done

- [ ] `canvas/` переименован в `engine/`
- [ ] Все классы переименованы
- [ ] `llmteam[engine]` в pyproject.toml
- [ ] Lazy imports в `__init__.py`
- [ ] LLMTeam работает без Engine (simple flow)
- [ ] ImportError с понятным сообщением при отсутствии Engine
- [ ] Тесты Core-only проходят
- [ ] Тесты Engine проходят
- [ ] Deprecation warnings для старых имён
- [ ] Документация обновлена

---

**Рекомендация: ПРИНЯТЬ**

Делает библиотеку модульной и лёгкой для простых use cases.

# RFC-006: Canvas → LLMTeamRuntimeEngine

**Дата:** 2026-01-21  
**Статус:** DRAFT  
**Автор:** @Architect  
**Приоритет:** P0 (базовый)

---

## TL;DR

| Аспект | Значение |
|--------|----------|
| **Изменение** | Переименовать `canvas/` в `runtime/` (LLMTeamRuntimeEngine) |
| **Суть** | Ребрендинг, не рефакторинг |
| **Breaking Changes** | Да (imports) |
| **Код меняется** | Минимально (имена) |

---

## 1. Мотивация

### 1.1 Проблема с названием "Canvas"

**Canvas** вызывает неправильные ассоциации:
- "Canvas" → визуальный редактор, UI
- "Canvas" → HTML canvas, рисование
- "Canvas" → дизайн-инструмент

**Реальность:** Это runtime engine для выполнения workflow.

### 1.2 Почему LLMTeamRuntimeEngine

| Название | Значение |
|----------|----------|
| LLMTeam | Принадлежность к библиотеке |
| Runtime | Выполнение в реальном времени |
| Engine | Движок, машина выполнения |

**LLMTeamRuntimeEngine** — движок выполнения команд LLMTeam.

---

## 2. Изменения

### 2.1 Файловая структура

```
BEFORE:                          AFTER:
llmteam/                         llmteam/
├── canvas/                      ├── runtime/
│   ├── __init__.py             │   ├── __init__.py
│   ├── models.py               │   ├── models.py
│   ├── catalog.py              │   ├── catalog.py
│   ├── runner.py       →       │   ├── engine.py          # Renamed
│   ├── validation.py           │   ├── validation.py
│   ├── exceptions.py           │   ├── exceptions.py
│   └── handlers/               │   └── handlers/
│       ├── __init__.py         │       ├── __init__.py
│       ├── llm_handler.py      │       ├── llm_handler.py
│       ├── rag_handler.py      │       ├── rag_handler.py
│       └── ...                 │       └── ...
```

### 2.2 Переименование классов

| Before | After |
|--------|-------|
| `SegmentRunner` | `RuntimeEngine` |
| `SegmentDefinition` | `WorkflowDefinition` |
| `SegmentResult` | `ExecutionResult` |
| `SegmentStatus` | `ExecutionStatus` |
| `SegmentSnapshot` | `ExecutionSnapshot` |
| `CanvasError` | `RuntimeError` (или `EngineError`) |

### 2.3 Imports

```python
# BEFORE
from llmteam.canvas import SegmentRunner, SegmentDefinition
from llmteam.canvas.runner import SegmentStatus

# AFTER
from llmteam.runtime import RuntimeEngine, WorkflowDefinition
from llmteam.runtime.engine import ExecutionStatus
```

### 2.4 Public API в __init__.py

```python
# llmteam/__init__.py

# BEFORE (Canvas exports)
from llmteam.canvas import (
    SegmentDefinition,
    SegmentRunner,
    SegmentResult,
    SegmentStatus,
    SegmentSnapshot,
    StepCatalog,
    # ...
)

# AFTER (Runtime exports)
from llmteam.runtime import (
    WorkflowDefinition,
    RuntimeEngine,
    ExecutionResult,
    ExecutionStatus,
    ExecutionSnapshot,
    StepCatalog,
    # ...
)

# Backward compatibility (deprecated)
import warnings

def __getattr__(name):
    """Deprecated Canvas imports."""
    mapping = {
        "SegmentRunner": "RuntimeEngine",
        "SegmentDefinition": "WorkflowDefinition",
        "SegmentResult": "ExecutionResult",
        "SegmentStatus": "ExecutionStatus",
        "SegmentSnapshot": "ExecutionSnapshot",
    }
    if name in mapping:
        warnings.warn(
            f"{name} is deprecated, use {mapping[name]} instead",
            DeprecationWarning,
            stacklevel=2
        )
        from llmteam import runtime
        return getattr(runtime, mapping[name])
    raise AttributeError(f"module 'llmteam' has no attribute '{name}'")
```

---

## 3. Детали переименования

### 3.1 engine.py (бывший runner.py)

```python
# llmteam/runtime/engine.py

class RuntimeEngine:
    """
    LLMTeam Runtime Engine.
    
    Выполняет workflow определённые в WorkflowDefinition.
    Бывший SegmentRunner.
    """
    
    def __init__(
        self,
        catalog: StepCatalog = None,
        snapshot_store: ExecutionSnapshotStore = None,
    ):
        self._catalog = catalog or StepCatalog()
        self._snapshot_store = snapshot_store
        self._running: Dict[str, asyncio.Task] = {}
        self._paused: Set[str] = set()
        # ...
    
    async def run(
        self,
        workflow: WorkflowDefinition,
        input_data: Dict[str, Any],
        runtime: RuntimeContext,
        config: RunConfig = None,
    ) -> ExecutionResult:
        """
        Execute a workflow.
        
        Args:
            workflow: Workflow definition (бывший SegmentDefinition)
            input_data: Input data
            runtime: Runtime context
            config: Execution configuration
        
        Returns:
            ExecutionResult (бывший SegmentResult)
        """
        # ... логика без изменений ...
    
    async def pause(self, run_id: str) -> Optional[str]:
        """Pause execution and create snapshot."""
        # ... логика без изменений ...
    
    async def resume(
        self,
        snapshot_id: str,
        runtime: RuntimeContext,
        config: RunConfig = None,
    ) -> ExecutionResult:
        """Resume execution from snapshot."""
        # ... логика без изменений ...
    
    async def cancel(self, run_id: str) -> bool:
        """Cancel execution."""
        # ... логика без изменений ...
```

### 3.2 models.py

```python
# llmteam/runtime/models.py

@dataclass
class WorkflowDefinition:
    """
    Definition of a workflow to execute.
    
    Бывший SegmentDefinition.
    """
    workflow_id: str
    name: str
    description: str = ""
    steps: List[StepDefinition] = field(default_factory=list)
    edges: List[EdgeDefinition] = field(default_factory=list)
    entrypoint: Optional[str] = None
    # ...


class ExecutionStatus(Enum):
    """
    Status of execution.
    
    Бывший SegmentStatus.
    """
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"


@dataclass
class ExecutionResult:
    """
    Result of workflow execution.
    
    Бывший SegmentResult.
    """
    run_id: str
    workflow_id: str
    status: ExecutionStatus
    output: Any = None
    error: Optional[ErrorInfo] = None
    started_at: datetime = None
    completed_at: datetime = None
    duration_ms: int = 0
    # ...


@dataclass
class ExecutionSnapshot:
    """
    Snapshot for pause/resume.
    
    Бывший SegmentSnapshot.
    """
    snapshot_id: str
    run_id: str
    workflow_id: str
    current_step: str
    completed_steps: List[str]
    step_outputs: Dict[str, Any]
    # ...
```

### 3.3 exceptions.py

```python
# llmteam/runtime/exceptions.py

class EngineError(Exception):
    """
    Base exception for runtime engine.
    
    Бывший CanvasError.
    """
    pass


class WorkflowValidationError(EngineError):
    """
    Workflow validation failed.
    
    Бывший SegmentValidationError.
    """
    pass


class StepTypeNotFoundError(EngineError):
    """Step type not registered."""
    pass


class InvalidStepConfigError(EngineError):
    """Invalid step configuration."""
    pass
```

---

## 4. Migration Guide

### 4.1 Для пользователей библиотеки

```python
# BEFORE
from llmteam import SegmentRunner, SegmentDefinition

runner = SegmentRunner()
segment = SegmentDefinition(segment_id="test", ...)
result = await runner.run(segment, input_data, runtime)

# AFTER
from llmteam import RuntimeEngine, WorkflowDefinition

engine = RuntimeEngine()
workflow = WorkflowDefinition(workflow_id="test", ...)
result = await engine.run(workflow, input_data, runtime)
```

### 4.2 Таблица замен

| Before | After |
|--------|-------|
| `from llmteam.canvas import ...` | `from llmteam.runtime import ...` |
| `SegmentRunner()` | `RuntimeEngine()` |
| `SegmentDefinition(segment_id=...)` | `WorkflowDefinition(workflow_id=...)` |
| `SegmentResult` | `ExecutionResult` |
| `SegmentStatus.RUNNING` | `ExecutionStatus.RUNNING` |
| `SegmentSnapshot` | `ExecutionSnapshot` |
| `CanvasError` | `EngineError` |

### 4.3 Deprecation Period

```
v4.1: Новые имена + старые с DeprecationWarning
v5.0: Старые имена удалены
```

---

## 5. Оценка рисков

### 5.1 Матрица рисков

| Риск | Вероятность | Влияние | Итог | Митигация |
|------|-------------|---------|------|-----------|
| Сломанные imports у пользователей | Высокая | Среднее | HIGH | Deprecation warnings + period |
| Путаница в документации | Средняя | Низкое | LOW | Обновить всю документацию |
| Несогласованность в коде | Средняя | Низкое | LOW | Grep + replace |
| Runtime конфликт имён | Низкая | Высокое | MEDIUM | Использовать `EngineError` вместо `RuntimeError` |

### 5.2 Оценка рисков: **СРЕДНИЙ**

Основной риск — breaking changes в imports. Митигация: deprecation period.

---

## 6. Оценка целесообразности

### 6.1 Преимущества

| Преимущество | Вес |
|--------------|-----|
| Понятное название (Runtime vs Canvas) | ⭐⭐⭐ |
| Консистентность с LLMTeam | ⭐⭐ |
| Нет путаницы с UI/визуальными инструментами | ⭐⭐ |
| Лучше отражает суть компонента | ⭐⭐ |

### 6.2 Недостатки

| Недостаток | Вес |
|------------|-----|
| Breaking change | ⭐⭐⭐ |
| Нужно обновить документацию | ⭐⭐ |
| Нужно обновить примеры | ⭐ |

### 6.3 Вердикт: **УМЕРЕННО ЦЕЛЕСООБРАЗНО**

**ROI:** Средний. Улучшает понимание, но требует работы по миграции.

**Рекомендация:** Делать в составе мажорного релиза (v5.0) или если уже планируется breaking change.

---

## 7. План реализации

| День | Задача |
|------|--------|
| D1 | Переименовать директорию canvas/ → runtime/ |
| D1 | Переименовать runner.py → engine.py |
| D2 | Переименовать классы в models.py |
| D2 | Переименовать exceptions |
| D3 | Обновить все внутренние imports |
| D3 | Добавить deprecation __getattr__ |
| D4 | Обновить __init__.py exports |
| D5 | Обновить документацию |
| D5 | Обновить примеры |

**Общее время: 1 неделя**

---

## 8. Зависимости

- **Зависит от:** Ничего
- **Блокирует:** RFC-005 (CONFIGURATOR), RFC-007 (Agent encapsulation)
- **Рекомендуется:** Делать первым, остальные RFC используют новые имена

---

## 9. Альтернативы

### 9.1 Не переименовывать

**Плюсы:** Нет breaking changes
**Минусы:** Путающее название остаётся

### 9.2 Переименовать только в документации

**Плюсы:** Нет breaking changes в коде
**Минусы:** Несоответствие кода и документации

### 9.3 Полный рефакторинг (удаление Canvas)

**Плюсы:** Чистая архитектура
**Минусы:** Потеря функционала, большой риск

**Выбор:** Вариант по умолчанию (переименование) — баланс между чистотой и риском.

---

## 10. Definition of Done

- [ ] Директория `canvas/` переименована в `runtime/`
- [ ] `runner.py` переименован в `engine.py`
- [ ] Все классы переименованы по таблице
- [ ] Все внутренние imports обновлены
- [ ] Public exports в `__init__.py` обновлены
- [ ] Deprecation warnings для старых имён
- [ ] Документация обновлена
- [ ] Примеры обновлены
- [ ] Migration guide написан

---

**Рекомендация: ПРИНЯТЬ (в составе мажорного релиза)**

Средний риск, умеренная целесообразность. Делать вместе с другими breaking changes.

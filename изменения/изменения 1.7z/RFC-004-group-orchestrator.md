# RFC-004: GroupOrchestrator — Отдельный класс координации команд

**Дата:** 2026-01-21  
**Статус:** DRAFT  
**Автор:** @Architect  
**Приоритет:** P2

---

## TL;DR

| Аспект | Значение |
|--------|----------|
| **Изменение** | Вынести GroupOrchestrator за пределы LLMTeam в отдельный класс |
| **Роль по умолчанию** | REPORT_COLLECTOR — сбор отчётов с TeamOrchestrator |
| **Зависимости** | Нет (независимый RFC) |
| **Breaking Changes** | Нет (новый функционал) |

---

## 1. Мотивация

### 1.1 Текущее состояние

Сейчас `LLMGroup` — это контейнер команд без интеллекта:

```python
class LLMGroup:
    def __init__(self, teams: List[LLMTeam]):
        self._teams = teams
    
    async def run(self, input_data):
        # Простое последовательное выполнение
        for team in self._teams:
            result = await team.run(input_data)
        return result
```

**Проблемы:**
- Нет координации между командами
- Нет сбора отчётов
- Нет общего контекста
- Логика координации размазана по коду пользователя

### 1.2 Предлагаемое решение

`GroupOrchestrator` — отдельный класс, координирующий работу нескольких `LLMTeam`:

```python
group_orch = GroupOrchestrator(
    role=GroupRole.REPORT_COLLECTOR  # Роль по умолчанию
)
group_orch.add_team(team1)
group_orch.add_team(team2)

result = await group_orch.execute(input_data)
# result.team_reports — отчёты со всех TeamOrchestrator
```

---

## 2. Архитектура

### 2.1 Место в системе

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   User Code                                                     │
│       │                                                         │
│       ▼                                                         │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │ GroupOrchestrator                                       │  │
│   │                                                         │  │
│   │   role: REPORT_COLLECTOR (default)                     │  │
│   │                                                         │  │
│   │   • Координирует команды                               │  │
│   │   • Собирает отчёты                                    │  │
│   │   • Агрегирует результаты                              │  │
│   │                                                         │  │
│   └─────────────────────────────────────────────────────────┘  │
│                              │                                  │
│              ┌───────────────┼───────────────┐                  │
│              ▼               ▼               ▼                  │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│   │   LLMTeam    │  │   LLMTeam    │  │   LLMTeam    │        │
│   │      +       │  │      +       │  │      +       │        │
│   │TeamOrchestrator│TeamOrchestrator│TeamOrchestrator│        │
│   └──────────────┘  └──────────────┘  └──────────────┘        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Роль по умолчанию: REPORT_COLLECTOR

```python
class GroupRole(Enum):
    """Роли GroupOrchestrator."""
    
    REPORT_COLLECTOR = "report_collector"
    """
    Роль по умолчанию.
    
    Поведение:
    1. Выполняет все команды
    2. Собирает TeamReport с каждого TeamOrchestrator
    3. Агрегирует в GroupReport
    4. Возвращает результат + отчёты
    
    Не принимает решений, не изменяет flow.
    """
```

### 2.3 Классы

```python
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class GroupRole(Enum):
    """Роли GroupOrchestrator. MVP: только REPORT_COLLECTOR."""
    REPORT_COLLECTOR = "report_collector"
    # Будущие роли (P3+):
    # COORDINATOR = "coordinator"
    # AGGREGATOR = "aggregator"
    # ARBITER = "arbiter"


@dataclass
class TeamReport:
    """Отчёт от TeamOrchestrator."""
    team_id: str
    run_id: str
    success: bool
    duration_ms: int
    agents_executed: List[str]
    agent_reports: List[Dict[str, Any]]
    output_summary: str
    errors: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class GroupReport:
    """Агрегированный отчёт от GroupOrchestrator."""
    group_id: str
    role: GroupRole
    teams_count: int
    teams_succeeded: int
    teams_failed: int
    total_duration_ms: int
    team_reports: List[TeamReport]
    summary: str
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class GroupResult:
    """Результат выполнения группы."""
    success: bool
    output: Dict[str, Any]
    team_results: Dict[str, Any]  # team_id -> RunResult
    report: GroupReport
    errors: List[str] = field(default_factory=list)


class GroupOrchestrator:
    """
    Orchestrator для группы команд.
    
    MVP: роль REPORT_COLLECTOR — собирает отчёты с TeamOrchestrator.
    """
    
    def __init__(
        self,
        group_id: str = None,
        role: GroupRole = GroupRole.REPORT_COLLECTOR,
    ):
        self.group_id = group_id or f"group_{uuid.uuid4().hex[:8]}"
        self._role = role
        self._teams: Dict[str, "LLMTeam"] = {}
    
    # === Team Management ===
    
    def add_team(self, team: "LLMTeam") -> None:
        """Добавить команду."""
        self._teams[team.team_id] = team
    
    def remove_team(self, team_id: str) -> bool:
        """Удалить команду."""
        return self._teams.pop(team_id, None) is not None
    
    def list_teams(self) -> List[str]:
        """Список ID команд."""
        return list(self._teams.keys())
    
    def get_team(self, team_id: str) -> Optional["LLMTeam"]:
        """Получить команду по ID."""
        return self._teams.get(team_id)
    
    # === Execution ===
    
    async def execute(
        self,
        input_data: Dict[str, Any],
        parallel: bool = False,
    ) -> GroupResult:
        """
        Выполнить все команды и собрать отчёты.
        
        Args:
            input_data: Входные данные для всех команд
            parallel: Выполнять команды параллельно
        
        Returns:
            GroupResult с результатами и отчётами
        """
        start_time = datetime.utcnow()
        team_results = {}
        team_reports = []
        errors = []
        
        if parallel:
            team_results, team_reports, errors = await self._execute_parallel(input_data)
        else:
            team_results, team_reports, errors = await self._execute_sequential(input_data)
        
        # Агрегируем отчёт
        duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        group_report = self._create_group_report(team_reports, duration_ms)
        
        return GroupResult(
            success=len(errors) == 0,
            output=self._merge_outputs(team_results),
            team_results=team_results,
            report=group_report,
            errors=errors,
        )
    
    async def _execute_sequential(
        self,
        input_data: Dict[str, Any],
    ) -> Tuple[Dict, List[TeamReport], List[str]]:
        """Последовательное выполнение команд."""
        team_results = {}
        team_reports = []
        errors = []
        
        for team_id, team in self._teams.items():
            try:
                result = await team.run(input_data)
                team_results[team_id] = result
                
                # Получаем отчёт от TeamOrchestrator
                report = team.get_last_report()
                if report:
                    team_reports.append(report)
                
            except Exception as e:
                errors.append(f"{team_id}: {str(e)}")
        
        return team_results, team_reports, errors
    
    async def _execute_parallel(
        self,
        input_data: Dict[str, Any],
    ) -> Tuple[Dict, List[TeamReport], List[str]]:
        """Параллельное выполнение команд."""
        import asyncio
        
        async def run_team(team_id: str, team: "LLMTeam"):
            result = await team.run(input_data)
            report = team.get_last_report()
            return team_id, result, report
        
        tasks = [run_team(tid, t) for tid, t in self._teams.items()]
        completed = await asyncio.gather(*tasks, return_exceptions=True)
        
        team_results = {}
        team_reports = []
        errors = []
        
        for item in completed:
            if isinstance(item, Exception):
                errors.append(str(item))
            else:
                team_id, result, report = item
                team_results[team_id] = result
                if report:
                    team_reports.append(report)
        
        return team_results, team_reports, errors
    
    def _create_group_report(
        self,
        team_reports: List[TeamReport],
        duration_ms: int,
    ) -> GroupReport:
        """Создать агрегированный отчёт."""
        succeeded = sum(1 for r in team_reports if r.success)
        failed = len(team_reports) - succeeded
        
        summary = f"Executed {len(team_reports)} teams: {succeeded} succeeded, {failed} failed"
        
        return GroupReport(
            group_id=self.group_id,
            role=self._role,
            teams_count=len(team_reports),
            teams_succeeded=succeeded,
            teams_failed=failed,
            total_duration_ms=duration_ms,
            team_reports=team_reports,
            summary=summary,
        )
    
    def _merge_outputs(self, team_results: Dict) -> Dict[str, Any]:
        """Объединить выходы всех команд."""
        merged = {}
        for team_id, result in team_results.items():
            if hasattr(result, 'output'):
                merged[team_id] = result.output
            elif hasattr(result, 'final_output'):
                merged[team_id] = result.final_output
        return merged
    
    @property
    def role(self) -> GroupRole:
        """Текущая роль."""
        return self._role
```

---

## 3. Интеграция с LLMGroup

```python
class LLMGroup:
    """
    Группа команд с GroupOrchestrator.
    
    Удобная обёртка для GroupOrchestrator.
    """
    
    def __init__(
        self,
        group_id: str = None,
        teams: List["LLMTeam"] = None,
    ):
        self._orchestrator = GroupOrchestrator(group_id=group_id)
        
        if teams:
            for team in teams:
                self._orchestrator.add_team(team)
    
    def add_team(self, team: "LLMTeam") -> None:
        """Добавить команду."""
        self._orchestrator.add_team(team)
    
    def remove_team(self, team_id: str) -> bool:
        """Удалить команду."""
        return self._orchestrator.remove_team(team_id)
    
    async def run(
        self,
        input_data: Dict[str, Any],
        parallel: bool = False,
    ) -> GroupResult:
        """
        Выполнить группу команд.
        
        Args:
            input_data: Входные данные
            parallel: Параллельное выполнение
        
        Returns:
            GroupResult с результатами и отчётами
        """
        return await self._orchestrator.execute(input_data, parallel=parallel)
    
    @property
    def report(self) -> Optional[GroupReport]:
        """Последний отчёт."""
        # TODO: реализовать хранение
        pass
```

---

## 4. Пример использования

```python
from llmteam import LLMTeam, LLMGroup, GroupOrchestrator

# Создаём команды
research = LLMTeam(team_id="research")
research.add_agent({"role": "searcher", "type": "rag", ...})
research.add_agent({"role": "analyzer", "type": "llm", ...})

writing = LLMTeam(team_id="writing")
writing.add_agent({"role": "writer", "type": "llm", ...})
writing.add_agent({"role": "editor", "type": "llm", ...})

# Вариант 1: Через LLMGroup
group = LLMGroup(group_id="content_pipeline", teams=[research, writing])
result = await group.run({"topic": "AI trends"})

print(result.report.summary)
# "Executed 2 teams: 2 succeeded, 0 failed"

for team_report in result.report.team_reports:
    print(f"{team_report.team_id}: {team_report.duration_ms}ms")
    print(f"  Agents: {team_report.agents_executed}")

# Вариант 2: Через GroupOrchestrator напрямую
orch = GroupOrchestrator(group_id="my_group")
orch.add_team(research)
orch.add_team(writing)

result = await orch.execute({"topic": "AI trends"}, parallel=True)
```

---

## 5. Оценка рисков

### 5.1 Матрица рисков

| Риск | Вероятность | Влияние | Итог | Митигация |
|------|-------------|---------|------|-----------|
| Усложнение API | Низкая | Низкое | LOW | LLMGroup как простая обёртка |
| Overhead на сбор отчётов | Низкая | Низкое | LOW | Отчёты уже генерируются TeamOrchestrator |
| Несовместимость отчётов | Средняя | Среднее | MEDIUM | Стандартизировать TeamReport формат |
| Путаница Team vs Group | Средняя | Низкое | LOW | Чёткая документация |

### 5.2 Оценка рисков: **НИЗКИЙ**

Изменение аддитивное (новый функционал), не ломает существующий код.

---

## 6. Оценка целесообразности

### 6.1 Преимущества

| Преимущество | Вес |
|--------------|-----|
| Централизованный сбор отчётов | ⭐⭐⭐ |
| Единая точка координации | ⭐⭐⭐ |
| Основа для будущих ролей (COORDINATOR, ARBITER) | ⭐⭐ |
| Чистое разделение Team vs Group | ⭐⭐ |

### 6.2 Недостатки

| Недостаток | Вес |
|------------|-----|
| Дополнительный класс в API | ⭐ |
| Нужно поддерживать два уровня отчётов | ⭐ |

### 6.3 Вердикт: **ЦЕЛЕСООБРАЗНО**

**ROI:** Высокий. Минимальные затраты, хорошая основа для расширения.

---

## 7. План реализации

| Неделя | Задача |
|--------|--------|
| W1 | GroupRole enum, TeamReport, GroupReport |
| W1 | GroupOrchestrator базовый класс |
| W2 | Интеграция с LLMGroup |
| W2 | Тесты, документация |

**Общее время: 2 недели**

---

## 8. Зависимости

- **Зависит от:** Ничего (независимый RFC)
- **Блокирует:** Будущие роли GroupOrchestrator (P3+)

---

## 9. Definition of Done

- [ ] GroupOrchestrator класс реализован
- [ ] GroupRole.REPORT_COLLECTOR работает
- [ ] TeamReport собирается с каждого TeamOrchestrator
- [ ] GroupReport агрегирует TeamReport'ы
- [ ] LLMGroup использует GroupOrchestrator
- [ ] Тесты: sequential/parallel execution
- [ ] Документация обновлена

---

**Рекомендация: ПРИНЯТЬ**

Низкий риск, высокая целесообразность, быстрая реализация.

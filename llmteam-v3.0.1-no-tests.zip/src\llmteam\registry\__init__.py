"""
Registries.
"""
from typing import Optional, Generic, TypeVar, Dict, Any

T = TypeVar("T")

class BaseRegistry(Generic[T]):
    def __init__(self, owner: Any = None):
        self._items: Dict[str, T] = {}
        self.owner = owner

    def register(self, item: T) -> None:
        pass

    def get(self, name: str) -> T:
        raise KeyError(name)

    def get_optional(self, name: str) -> Optional[T]:
        return self._items.get(name)

class AgentRegistry(BaseRegistry['Agent']): # Forward ref
    pass

class TeamRegistry(BaseRegistry['LLMTeam']): # Forward ref
    def register_team(self, team: Any) -> None:
        pass

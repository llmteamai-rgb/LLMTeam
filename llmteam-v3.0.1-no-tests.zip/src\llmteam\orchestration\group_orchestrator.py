"""
Group Orchestrator for LLMTeam.

Coordinates multiple teams and handles escalations.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional
import uuid

from llmteam.registry.team_registry import TeamRegistry

if TYPE_CHECKING:
    from llmteam.team import LLMTeam
    from llmteam.escalation.models import Escalation, EscalationDecision


@dataclass
class GroupMetrics:
    """Metrics collected by the group orchestrator."""

    total_teams: int = 0
    healthy_teams: int = 0
    available_teams: int = 0
    total_escalations: int = 0
    escalations_by_level: Dict[str, int] = field(default_factory=dict)
    escalations_by_team: Dict[str, int] = field(default_factory=dict)
    health_score: float = 1.0
    collected_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_teams": self.total_teams,
            "healthy_teams": self.healthy_teams,
            "available_teams": self.available_teams,
            "total_escalations": self.total_escalations,
            "escalations_by_level": self.escalations_by_level,
            "escalations_by_team": self.escalations_by_team,
            "health_score": self.health_score,
            "collected_at": self.collected_at.isoformat(),
        }


class GroupOrchestrator:
    """
    Coordinator for multiple teams.

    GroupOrchestrator is a pure coordinator that:
    - Owns a TeamRegistry for managing teams
    - Handles escalations from teams
    - Collects metrics about team health
    - Does NOT route between teams (Canvas does that)

    Example:
        group = GroupOrchestrator("support_group")
        group.register_team(triage_team)
        group.register_team(billing_team)

        # Handle escalation from a team
        decision = await group.handle_escalation(escalation)

        # Get metrics
        metrics = group.collect_metrics()
    """

    def __init__(
        self,
        group_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ):
        """
        Initialize group orchestrator.

        Args:
            group_id: Unique identifier for the group.
            name: Human-readable name.
            description: Description of the group.
        """
        self._group_id = group_id
        self._name = name or group_id
        self._description = description or ""

        # Team registry
        self._teams = TeamRegistry()

        # Escalation handling
        self._escalation_history: List[Dict[str, Any]] = []
        self._escalation_handlers: Dict[str, Callable] = {}

        # Health tracking
        self._health_score: float = 1.0

    @property
    def group_id(self) -> str:
        """Unique identifier for the group."""
        return self._group_id

    @property
    def name(self) -> str:
        """Human-readable name."""
        return self._name

    @property
    def description(self) -> str:
        """Description of the group."""
        return self._description

    @property
    def teams(self) -> TeamRegistry:
        """Registry of teams in this group."""
        return self._teams

    def register_team(self, team: "LLMTeam") -> None:
        """
        Register a team with this group.

        Args:
            team: Team to register.
        """
        team.group = self
        self._teams.register_team(team)

    def unregister_team(self, team_id: str) -> "LLMTeam":
        """
        Remove a team from this group.

        Args:
            team_id: ID of team to remove.

        Returns:
            The removed team.
        """
        team = self._teams.unregister(team_id)
        team.group = None
        return team

    def get_team(self, team_id: str) -> Optional["LLMTeam"]:
        """
        Get a team by ID.

        Args:
            team_id: ID of team to get.

        Returns:
            The team or None.
        """
        return self._teams.get_optional(team_id)

    def list_teams(self) -> List["LLMTeam"]:
        """
        List all teams in this group.

        Returns:
            List of teams.
        """
        return self._teams.list()

    async def handle_escalation(
        self,
        escalation: "Escalation",
        handler: Optional[Callable[["Escalation"], "EscalationDecision"]] = None,
    ) -> "EscalationDecision":
        """
        Handle an escalation from a team.

        Args:
            escalation: The escalation to handle.
            handler: Optional custom handler.

        Returns:
            Decision on how to handle the escalation.
        """
        from llmteam.escalation.models import (
            EscalationLevel,
            EscalationAction,
            EscalationDecision,
        )

        # Record in history
        self._escalation_history.append({
            "escalation_id": escalation.escalation_id,
            "level": escalation.level.value,
            "source": escalation.source_team,
            "reason": escalation.reason,
            "timestamp": datetime.utcnow().isoformat(),
        })

        # Update health score based on escalation level
        self._update_health(escalation.level)

        # Use custom handler if provided
        if handler is not None:
            return handler(escalation)

        # Default handling based on level
        if escalation.level == EscalationLevel.INFO:
            return EscalationDecision(
                action=EscalationAction.ACKNOWLEDGE,
                message="Acknowledged",
            )

        elif escalation.level == EscalationLevel.WARNING:
            # Try to redirect to another team
            alternative = self._find_alternative_team(escalation.source_team)
            if alternative:
                return EscalationDecision(
                    action=EscalationAction.REDIRECT,
                    target_team=alternative.team_id,
                    message=f"Redirecting to {alternative.name}",
                )
            return EscalationDecision(
                action=EscalationAction.RETRY,
                message="Retrying with same team",
            )

        elif escalation.level == EscalationLevel.CRITICAL:
            return EscalationDecision(
                action=EscalationAction.HUMAN_REVIEW,
                message="Escalated for human review",
                metadata={"escalation": escalation.to_dict()},
            )

        else:  # EMERGENCY
            return EscalationDecision(
                action=EscalationAction.ABORT,
                message="Emergency: aborting operation",
            )

    async def handle_team_escalation(self, escalation_data: Dict[str, Any]) -> None:
        """
        Handle an escalation from a team (internal use).

        Args:
            escalation_data: Escalation data from team.
        """
        from llmteam.escalation.models import Escalation, EscalationLevel

        escalation = Escalation(
            escalation_id=str(uuid.uuid4()),
            level=EscalationLevel.WARNING,
            source_team=escalation_data.get("team_id", "unknown"),
            reason=escalation_data.get("reason", "Unknown reason"),
            context=escalation_data.get("context", {}),
        )

        await self.handle_escalation(escalation)

    def _find_alternative_team(self, exclude_team_id: str) -> Optional["LLMTeam"]:
        """Find an alternative healthy team."""
        for team in self._teams.list_healthy():
            if team.team_id != exclude_team_id:
                return team
        return None

    def _update_health(self, level: "EscalationLevel") -> None:
        """Update health score based on escalation level."""
        from llmteam.escalation.models import EscalationLevel

        penalties = {
            EscalationLevel.INFO: 0.0,
            EscalationLevel.WARNING: 0.05,
            EscalationLevel.CRITICAL: 0.15,
            EscalationLevel.EMERGENCY: 0.30,
        }

        penalty = penalties.get(level, 0.0)
        self._health_score = max(0.0, self._health_score - penalty)

    def get_escalation_history(
        self,
        team_id: Optional[str] = None,
        level: Optional["EscalationLevel"] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """
        Get escalation history.

        Args:
            team_id: Filter by team ID.
            level: Filter by escalation level.
            limit: Maximum number of records.

        Returns:
            List of escalation records.
        """
        history = self._escalation_history.copy()

        if team_id:
            history = [e for e in history if e.get("source") == team_id]

        if level:
            history = [e for e in history if e.get("level") == level.value]

        # Most recent first
        history.reverse()

        return history[:limit]

    def collect_metrics(self) -> GroupMetrics:
        """
        Collect current metrics about the group.

        Returns:
            GroupMetrics with current state.
        """
        teams = self._teams.list()

        # Count by level
        level_counts: Dict[str, int] = {}
        team_counts: Dict[str, int] = {}

        for e in self._escalation_history:
            level = e.get("level", "unknown")
            source = e.get("source", "unknown")

            level_counts[level] = level_counts.get(level, 0) + 1
            team_counts[source] = team_counts.get(source, 0) + 1

        return GroupMetrics(
            total_teams=len(teams),
            healthy_teams=len(self._teams.list_healthy()),
            available_teams=len(self._teams.list_available()),
            total_escalations=len(self._escalation_history),
            escalations_by_level=level_counts,
            escalations_by_team=team_counts,
            health_score=self._health_score,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "group_id": self._group_id,
            "name": self._name,
            "description": self._description,
            "team_count": self._teams.count(),
            "team_ids": self._teams.get_team_ids(),
            "health_score": self._health_score,
        }

    def __repr__(self) -> str:
        return (
            f"GroupOrchestrator(group_id={self._group_id!r}, "
            f"teams={self._teams.count()})"
        )

"""
Agent registry for LLMTeam.

Provides specialized registry for managing agents within a team.
"""

from typing import TYPE_CHECKING, List, Optional

from llmteam.agent import Agent, AgentProtocol
from llmteam.registry.base import BaseRegistry

if TYPE_CHECKING:
    from llmteam.team import LLMTeam


class AgentRegistry(BaseRegistry[Agent]):
    """
    Specialized registry for agents.

    Manages agents within a team and handles back-references.

    Example:
        registry = AgentRegistry(team=my_team)
        registry.register("analyzer", AnalysisAgent("analyzer"))
        agent = registry.get("analyzer")
    """

    def __init__(
        self,
        team: Optional["LLMTeam"] = None,
        allow_overwrite: bool = False,
    ):
        """
        Initialize agent registry.

        Args:
            team: The team that owns this registry.
            allow_overwrite: Whether to allow overwriting agents.
        """
        super().__init__(name="agent_registry", allow_overwrite=allow_overwrite)
        self._team = team

    @property
    def team(self) -> Optional["LLMTeam"]:
        """The team that owns this registry."""
        return self._team

    @team.setter
    def team(self, value: Optional["LLMTeam"]) -> None:
        """Set the owning team and update all agents."""
        self._team = value
        for agent in self._items.values():
            agent.team = value

    def register(self, key: str, agent: Agent) -> None:
        """
        Register an agent.

        Sets the agent's team back-reference.

        Args:
            key: Unique key for the agent (usually agent_id).
            agent: Agent to register.
        """
        # Verify it's an Agent
        if not isinstance(agent, (Agent,)) and not isinstance(agent, AgentProtocol):
            raise TypeError(f"Expected Agent, got {type(agent).__name__}")

        # Set team back-reference
        if hasattr(agent, "team"):
            agent.team = self._team

        super().register(key, agent)

    def register_agent(self, agent: Agent) -> None:
        """
        Register an agent using its agent_id as key.

        Args:
            agent: Agent to register.
        """
        self.register(agent.agent_id, agent)

    def unregister(self, key: str) -> Agent:
        """
        Unregister an agent.

        Clears the agent's team back-reference.

        Args:
            key: Key of agent to remove.

        Returns:
            The removed agent.
        """
        agent = super().unregister(key)
        if hasattr(agent, "team"):
            agent.team = None
        return agent

    def get_by_name(self, name: str) -> Optional[Agent]:
        """
        Find an agent by name.

        Args:
            name: Agent name to search for.

        Returns:
            Agent with matching name, or None.
        """
        for agent in self._items.values():
            if agent.name == name:
                return agent
        return None

    def list_by_type(self, agent_type: type) -> List[Agent]:
        """
        List agents of a specific type.

        Args:
            agent_type: Type to filter by.

        Returns:
            List of agents of that type.
        """
        return [a for a in self._items.values() if isinstance(a, agent_type)]

    def get_agent_ids(self) -> List[str]:
        """
        Get list of all agent IDs.

        Returns:
            List of agent IDs.
        """
        return [a.agent_id for a in self._items.values()]

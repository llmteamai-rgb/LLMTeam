"""
V2.x Compatibility Layer.

Provides adapters and shims for v2.x code to work with v3.0.0 architecture.

Migration Guide:
    v2.x Code:
        orchestrator = PipelineOrchestrator(pipeline_id="support")
        orchestrator.register_agent("triage", triage_agent)
        result = await orchestrator.orchestrate(run_id, input_data)

    v3.0.0 Code:
        team = LLMTeam(team_id="support")
        team.register_agent(triage_agent)
        result = await team.run(input_data, run_id=run_id)

    Using Compat Layer:
        from llmteam.compat import LegacyPipelineOrchestrator

        # Works like v2.x
        orchestrator = LegacyPipelineOrchestrator(pipeline_id="support")
        orchestrator.register_agent("triage", triage_agent)
        result = await orchestrator.orchestrate(run_id, input_data)
"""

import warnings
from typing import Any, Dict, List, Optional

from llmteam.agent import Agent, AgentResult, AgentState
from llmteam.team import LLMTeam, TeamConfig, TeamResult
from llmteam.roles.contract import TeamContract


class LegacyAgentAdapter(Agent):
    """
    Adapts v2.x agent objects to v3.0.0 Agent interface.

    V2.x agents have:
        - async def process(state: dict) -> dict

    V3.0.0 agents have:
        - async def process(state: AgentState) -> AgentResult
    """

    def __init__(self, agent_id: str, legacy_agent: Any):
        """
        Initialize adapter.

        Args:
            agent_id: Agent ID to use.
            legacy_agent: V2.x agent object with process(dict) -> dict.
        """
        super().__init__(agent_id=agent_id)
        self._legacy_agent = legacy_agent

    async def process(self, state: AgentState) -> AgentResult:
        """Process using legacy agent."""
        result = await self._legacy_agent.process(state.data)
        return AgentResult(
            output=result if isinstance(result, dict) else {"result": result},
            state=AgentState(data={**state.data, **(result if isinstance(result, dict) else {})}),
        )

    @property
    def legacy_agent(self) -> Any:
        """Get the wrapped legacy agent."""
        return self._legacy_agent


class LegacyPipelineOrchestrator:
    """
    V2.x PipelineOrchestrator compatibility shim.

    Wraps LLMTeam to provide v2.x API while using v3.0.0 internals.

    Example:
        # This v2.x code works unchanged:
        orchestrator = LegacyPipelineOrchestrator(pipeline_id="loan_approval")
        orchestrator.register_agent("validator", validator_agent)
        result = await orchestrator.orchestrate(run_id, input_data)
    """

    def __init__(
        self,
        pipeline_id: str,
        strategy: Optional[Any] = None,
        enable_process_mining: bool = True,
        contract: Optional[TeamContract] = None,
        strict_validation: bool = False,
    ):
        """
        Initialize legacy orchestrator.

        Args:
            pipeline_id: Pipeline ID (becomes team_id).
            strategy: Orchestration strategy (ignored in v3.0.0 simple mode).
            enable_process_mining: Whether to enable process mining (stored for compatibility).
            contract: TeamContract for validation.
            strict_validation: Whether to enforce strict validation.
        """
        warnings.warn(
            "LegacyPipelineOrchestrator is deprecated. "
            "Use LLMTeam for new code. See migration guide in llmteam.compat.v2",
            DeprecationWarning,
            stacklevel=2,
        )

        self._team = LLMTeam(
            team_id=pipeline_id,
            name=pipeline_id,
            contract=contract,
            config=TeamConfig(strict_validation=strict_validation),
        )

        # Store v2.x specific attributes
        self.pipeline_id = pipeline_id
        self.strategy = strategy
        self.enable_process_mining = enable_process_mining
        self.contract = contract or TeamContract.default()
        self.strict_validation = strict_validation

        # Agent name mapping (name -> adapted agent id)
        self._agent_names: Dict[str, str] = {}
        self._execution_history: List[dict] = []

    def register_agent(self, name: str, agent: Any) -> None:
        """
        Register an agent with v2.x API.

        Args:
            name: Agent name (used as agent_id).
            agent: Agent instance (v2.x style or v3.0.0 Agent).
        """
        # If already a v3.0.0 Agent, use directly
        if isinstance(agent, Agent):
            self._team.register_agent(agent)
            self._agent_names[name] = agent.agent_id
        else:
            # Wrap in adapter
            adapted = LegacyAgentAdapter(agent_id=name, legacy_agent=agent)
            self._team.register_agent(adapted)
            self._agent_names[name] = name

    def unregister_agent(self, name: str) -> None:
        """
        Unregister an agent.

        Args:
            name: Agent name.
        """
        if name in self._agent_names:
            self._team.unregister_agent(self._agent_names[name])
            del self._agent_names[name]

    async def orchestrate(self, run_id: str, input_data: dict) -> dict:
        """
        Execute pipeline orchestration with v2.x API.

        Args:
            run_id: Run identifier.
            input_data: Input data.

        Returns:
            Final state dictionary.
        """
        # Use team.run() internally
        result = await self._team.run(input_data, run_id=run_id)

        # Store execution record
        self._execution_history.append({
            "run_id": run_id,
            "success": result.success,
            "iterations": result.iterations,
            "agents_invoked": result.agents_invoked,
        })

        # Return just the output dict (v2.x API)
        if result.success:
            return result.output
        else:
            raise RuntimeError(result.error or "Orchestration failed")

    def get_execution_history(self) -> List[dict]:
        """Get execution history."""
        return self._execution_history.copy()

    def get_process_metrics(self) -> Optional[Any]:
        """
        Get process metrics (stub for compatibility).

        Returns:
            None (process mining not implemented in v3.0.0 yet).
        """
        warnings.warn(
            "Process mining is not yet implemented in v3.0.0",
            DeprecationWarning,
            stacklevel=2,
        )
        return None

    def export_process_model(self) -> Optional[str]:
        """
        Export process model (stub for compatibility).

        Returns:
            None (process mining not implemented in v3.0.0 yet).
        """
        warnings.warn(
            "Process mining is not yet implemented in v3.0.0",
            DeprecationWarning,
            stacklevel=2,
        )
        return None

    @property
    def team(self) -> LLMTeam:
        """Get the underlying LLMTeam."""
        return self._team


class PipelineOrchestratorAdapter:
    """
    Adapter to use old PipelineOrchestrator with new team-based code.

    Wraps a PipelineOrchestrator to provide LLMTeam-like interface.
    """

    def __init__(self, orchestrator: Any):
        """
        Initialize adapter.

        Args:
            orchestrator: V2.x PipelineOrchestrator instance.
        """
        self._orchestrator = orchestrator
        self._team_id = orchestrator.pipeline_id

    @property
    def team_id(self) -> str:
        """Get team ID."""
        return self._team_id

    async def run(
        self,
        input_data: Dict[str, Any],
        run_id: Optional[str] = None,
    ) -> TeamResult:
        """
        Run using v2.x orchestrator.

        Args:
            input_data: Input data.
            run_id: Run identifier.

        Returns:
            TeamResult.
        """
        import uuid
        actual_run_id = run_id or str(uuid.uuid4())

        try:
            result = await self._orchestrator.orchestrate(actual_run_id, input_data)
            return TeamResult(
                output=result,
                success=True,
                iterations=len(self._orchestrator.get_execution_history()),
            )
        except Exception as e:
            return TeamResult(
                success=False,
                error=str(e),
            )


def create_team_from_orchestrator(
    orchestrator: Any,
    team_id: Optional[str] = None,
) -> LLMTeam:
    """
    Create an LLMTeam from a v2.x PipelineOrchestrator.

    Migrates agents and configuration to new format.

    Args:
        orchestrator: V2.x PipelineOrchestrator.
        team_id: Optional team ID (defaults to orchestrator.pipeline_id).

    Returns:
        New LLMTeam instance.
    """
    team = LLMTeam(
        team_id=team_id or orchestrator.pipeline_id,
        contract=orchestrator.contract,
        config=TeamConfig(strict_validation=orchestrator.strict_validation),
    )

    # Migrate agents
    for name, agent in orchestrator._agents.items():
        if isinstance(agent, Agent):
            team.register_agent(agent)
        else:
            adapted = LegacyAgentAdapter(agent_id=name, legacy_agent=agent)
            team.register_agent(adapted)

    return team


def create_orchestrator_from_team(team: LLMTeam) -> LegacyPipelineOrchestrator:
    """
    Create a legacy PipelineOrchestrator from an LLMTeam.

    For use with code that expects v2.x API.

    Args:
        team: LLMTeam instance.

    Returns:
        LegacyPipelineOrchestrator wrapping the team.
    """
    # Create new orchestrator
    orchestrator = LegacyPipelineOrchestrator.__new__(LegacyPipelineOrchestrator)

    # Set up internal state
    orchestrator._team = team
    orchestrator.pipeline_id = team.team_id
    orchestrator.strategy = None
    orchestrator.enable_process_mining = False
    orchestrator.contract = team.contract
    orchestrator.strict_validation = team.config.strict_validation
    orchestrator._agent_names = {a.agent_id: a.agent_id for a in team.list_agents()}
    orchestrator._execution_history = []

    return orchestrator

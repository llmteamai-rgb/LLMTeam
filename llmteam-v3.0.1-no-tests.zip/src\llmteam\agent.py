"""
Agent Interface (v3.0.0).

Defines the base Agent class and AgentProtocol.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional, Protocol, runtime_checkable

if TYPE_CHECKING:
    from llmteam.team import LLMTeam
    from llmteam.escalation.models import EscalationLevel, EscalationDecision


@runtime_checkable
class AgentProtocol(Protocol):
    """
    Minimal agent interface for duck typing.
    """
    agent_id: str
    
    async def process(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Process state."""
        ...


class Agent(ABC):
    """
    Base Agent class.
    
    Attributes:
        agent_id: Unique identifier
        name: Human-readable name
        description: Description
    """
    
    # Required attributes
    agent_id: str
    
    # Optional attributes
    name: str = ""
    description: str = ""
    
    # Internal state
    _team: Optional[LLMTeam] = None
    
    def __init__(self, agent_id: Optional[str] = None, **kwargs):
        """Initialize agent."""
        if agent_id:
            self.agent_id = agent_id
        
        if not hasattr(self, 'agent_id') or not self.agent_id:
            raise ValueError(f"{self.__class__.__name__} must define 'agent_id'")
        
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    @property
    def team(self) -> Optional[LLMTeam]:
        """Get owning team."""
        return self._team
    
    @property
    def has_team(self) -> bool:
        """Check if part of a team."""
        return self._team is not None
    
    @abstractmethod
    async def process(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process state.
        
        Args:
            state: Current execution state
            
        Returns:
            Updated state (partial or full)
        """
        ...
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status."""
        return {"status": "available"}
    
    async def on_start(self) -> None:
        """Lifecycle hook: before process."""
        pass
    
    async def on_complete(self, result: Dict[str, Any]) -> None:
        """Lifecycle hook: after success."""
        pass
    
    async def on_error(self, error: Exception) -> None:
        """Lifecycle hook: on error."""
        pass
    
    async def escalate(
        self,
        level: EscalationLevel,
        reason: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> EscalationDecision:
        """
        Escalate to team -> group.
        
        Args:
            level: Escalation level
            reason: Reason for escalation
            context: Additional context
            
        Returns:
            Escalation decision
        """
        from llmteam.exceptions import NoTeamError
        
        if not self._team:
            raise NoTeamError(
                f"Agent '{self.agent_id}' cannot escalate: not part of any team"
            )
        
        return await self._team.escalate(
            level=level,
            reason=reason,
            context=context,
            source_agent=self.agent_id,
        )
    
    def __repr__(self) -> str:
        team_info = f" team='{self._team.team_id}'" if self._team else ""
        return f"<{self.__class__.__name__} id='{self.agent_id}'{team_info}>"
    
    def __eq__(self, other: object) -> bool:
        if isinstance(other, Agent):
            return self.agent_id == other.agent_id
        return False
    
@dataclass
class AgentState:
    data: Dict[str, Any]

@dataclass
class AgentResult:
    output: Dict[str, Any]
    should_escalate: bool = False

    def __hash__(self) -> int:
        return hash(self.output.get("id", str(self.output)))
class LLMConfig:
    model: str
    temperature: float = 0.0

class LLMAgent(Agent):
    def __init__(self, agent_id: str, config: Optional[LLMConfig] = None):
        super().__init__(agent_id=agent_id)
        self.config = config

    async def process(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {}

class FunctionAgent(Agent):
    async def process(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {}

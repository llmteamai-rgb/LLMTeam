"""
Compatibility Layer.
"""
class Pipeline: pass
class LegacyPipelineOrchestrator: pass

"""
Team Orchestrator for LLMTeam.

Handles the execution flow within a single team.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional
import uuid

from llmteam.agent import Agent, AgentResult, AgentState

if TYPE_CHECKING:
    from llmteam.team import LLMTeam, TeamResult


class OrchestrationMode(Enum):
    """How agents are executed within a team."""

    SEQUENTIAL = "sequential"  # One by one in order
    PARALLEL = "parallel"  # All at once
    ADAPTIVE = "adaptive"  # Strategy decides


@dataclass
class OrchestrationContext:
    """Context passed during orchestration."""

    run_id: str
    input_data: Dict[str, Any]
    current_agent: Optional[str] = None
    iteration: int = 0
    history: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OrchestrationDecision:
    """Decision made by orchestration strategy."""

    next_agent: Optional[str] = None
    should_continue: bool = True
    should_escalate: bool = False
    escalation_reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class OrchestrationStrategy(ABC):
    """
    Abstract strategy for deciding agent execution order.

    Subclass this to implement custom orchestration logic.
    """

    @abstractmethod
    def decide(
        self,
        context: OrchestrationContext,
        agents: List[Agent],
        last_result: Optional[AgentResult],
    ) -> OrchestrationDecision:
        """
        Decide what to do next.

        Args:
            context: Current orchestration context.
            agents: Available agents.
            last_result: Result from last agent (if any).

        Returns:
            Decision on next action.
        """
        ...


class SequentialStrategy(OrchestrationStrategy):
    """Execute agents in registration order."""

    def decide(
        self,
        context: OrchestrationContext,
        agents: List[Agent],
        last_result: Optional[AgentResult],
    ) -> OrchestrationDecision:
        """Execute next agent in sequence."""
        if not agents:
            return OrchestrationDecision(should_continue=False)

        # Find current index
        current_idx = -1
        if context.current_agent:
            for i, agent in enumerate(agents):
                if agent.agent_id == context.current_agent:
                    current_idx = i
                    break

        # Get next agent
        next_idx = current_idx + 1
        if next_idx >= len(agents):
            return OrchestrationDecision(should_continue=False)

        return OrchestrationDecision(
            next_agent=agents[next_idx].agent_id,
            should_continue=True,
        )


class RoundRobinStrategy(OrchestrationStrategy):
    """Execute agents in round-robin until condition met."""

    def __init__(self, max_rounds: int = 3):
        self.max_rounds = max_rounds
        self._round = 0

    def decide(
        self,
        context: OrchestrationContext,
        agents: List[Agent],
        last_result: Optional[AgentResult],
    ) -> OrchestrationDecision:
        """Execute agents in round-robin."""
        if not agents:
            return OrchestrationDecision(should_continue=False)

        # Check if we've exceeded max rounds
        if context.iteration >= len(agents) * self.max_rounds:
            return OrchestrationDecision(should_continue=False)

        # Get next agent in round-robin
        agent_idx = context.iteration % len(agents)
        return OrchestrationDecision(
            next_agent=agents[agent_idx].agent_id,
            should_continue=True,
        )


class LLMRoutingStrategy(OrchestrationStrategy):
    """Use an LLM to decide which agent to invoke next."""

    def __init__(self, llm_ref: str, system_prompt: Optional[str] = None):
        self.llm_ref = llm_ref
        self.system_prompt = system_prompt or (
            "You are an orchestrator. Given the current state and available agents, "
            "decide which agent should handle the request next. "
            "Respond with just the agent_id."
        )

    def decide(
        self,
        context: OrchestrationContext,
        agents: List[Agent],
        last_result: Optional[AgentResult],
    ) -> OrchestrationDecision:
        """
        Use LLM to decide (sync fallback - actual implementation needs async).
        """
        # For now, fallback to sequential
        # Full async implementation would require different design
        if not agents:
            return OrchestrationDecision(should_continue=False)

        # Simple fallback: use first available agent
        return OrchestrationDecision(
            next_agent=agents[0].agent_id,
            should_continue=True,
        )


class TeamOrchestrator:
    """
    Orchestrator for executing agents within a team.

    Manages the flow of execution between agents based on strategy.

    Example:
        orchestrator = TeamOrchestrator(strategy=SequentialStrategy())
        result = await orchestrator.orchestrate(team, input_data)
    """

    def __init__(
        self,
        strategy: Optional[OrchestrationStrategy] = None,
        max_iterations: int = 10,
        on_agent_start: Optional[Callable[[str, AgentState], None]] = None,
        on_agent_complete: Optional[Callable[[str, AgentResult], None]] = None,
    ):
        """
        Initialize orchestrator.

        Args:
            strategy: Strategy for deciding execution order.
            max_iterations: Maximum number of agent invocations.
            on_agent_start: Callback when agent starts.
            on_agent_complete: Callback when agent completes.
        """
        self._strategy = strategy or SequentialStrategy()
        self._max_iterations = max_iterations
        self._on_agent_start = on_agent_start
        self._on_agent_complete = on_agent_complete

    @property
    def strategy(self) -> OrchestrationStrategy:
        """Current orchestration strategy."""
        return self._strategy

    @strategy.setter
    def strategy(self, value: OrchestrationStrategy) -> None:
        """Set orchestration strategy."""
        self._strategy = value

    async def orchestrate(
        self,
        team: "LLMTeam",
        input_data: Dict[str, Any],
        run_id: Optional[str] = None,
    ) -> "TeamResult":
        """
        Orchestrate agent execution within a team.

        Args:
            team: The team to orchestrate.
            input_data: Input data for processing.
            run_id: Optional run identifier.

        Returns:
            TeamResult with output and metadata.
        """
        from llmteam.team import TeamResult

        run_id = run_id or str(uuid.uuid4())
        agents = team.list_agents()

        if not agents:
            return TeamResult(
                success=False,
                error="No agents registered in team",
            )

        # Initialize context
        context = OrchestrationContext(
            run_id=run_id,
            input_data=input_data,
        )
        state = AgentState(data=input_data.copy())
        agents_invoked: List[str] = []
        escalations: List[Dict[str, Any]] = []
        last_result: Optional[AgentResult] = None

        # Execution loop
        while context.iteration < self._max_iterations:
            # Get strategy decision
            decision = self._strategy.decide(context, agents, last_result)

            # Check if we should stop
            if not decision.should_continue or decision.next_agent is None:
                break

            # Check for escalation
            if decision.should_escalate:
                escalations.append({
                    "iteration": context.iteration,
                    "reason": decision.escalation_reason,
                    "agent": context.current_agent,
                })
                await team.handle_agent_escalation(
                    agent_id=context.current_agent or "orchestrator",
                    reason=decision.escalation_reason or "Strategy requested escalation",
                    context=state.data,
                )

            # Get the agent
            agent = team.get_agent(decision.next_agent)
            if agent is None:
                return TeamResult(
                    success=False,
                    error=f"Agent '{decision.next_agent}' not found",
                    agents_invoked=agents_invoked,
                )

            # Update context
            context.current_agent = decision.next_agent
            context.iteration += 1

            # Notify start
            if self._on_agent_start:
                self._on_agent_start(agent.agent_id, state)

            # Execute agent
            try:
                last_result = await agent.process(state)
                agents_invoked.append(agent.agent_id)

                # Update history
                context.history.append({
                    "agent_id": agent.agent_id,
                    "iteration": context.iteration,
                    "output": last_result.output,
                })

                # Update state
                if last_result.state:
                    state = last_result.state
                state.data.update(last_result.output)

                # Notify complete
                if self._on_agent_complete:
                    self._on_agent_complete(agent.agent_id, last_result)

                # Handle agent-initiated escalation
                if last_result.should_escalate:
                    escalations.append({
                        "iteration": context.iteration,
                        "reason": last_result.escalation_reason,
                        "agent": agent.agent_id,
                    })

            except Exception as e:
                return TeamResult(
                    success=False,
                    error=f"Agent '{agent.agent_id}' failed: {str(e)}",
                    iterations=context.iteration,
                    agents_invoked=agents_invoked,
                    escalations=escalations,
                )

        return TeamResult(
            output=state.data,
            success=True,
            iterations=context.iteration,
            agents_invoked=agents_invoked,
            escalations=escalations,
        )
